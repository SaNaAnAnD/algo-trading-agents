# Market Data Agent

**📊 Market Regime**  
- **SPY:** Bear (overall market downtrend)

---

### 💰 Account Snapshot
| Metric            | Amount (USD) |
|-------------------|--------------|
| **Cash**          | $85,808.17 |
| **Buying Power**  | $383,764.50 |
| **Portfolio Value** | $100,283.82 |
| **Equity**        | $100,283.82 |

---

### 📈 Open Positions  

| Symbol | Qty | Avg Entry | Current | Market Value | Unrealized P/L | % P/L |
|--------|-----|-----------|---------|--------------|----------------|-------|
| **AAPL** | 1 | $337.81 | $341.38 | $341.38 | +$3.57 | +1.06% |
| **COST** | 1 | $958.79 | $994.21 | $994.21 | +$35.42 | +3.69% |
| **LLY**  | 1 | $1,210.99 | $1,294.47 | $1,294.47 | +$83.48 | +6.89% |
| **XOM**  | 67 | $178.52 | $176.80 | $11,845.60 | –$115.19 | –0.96% |

*Overall portfolio is modestly up (+$122.28) despite the bear backdrop, driven mainly by LLY and COST gains.*

---

### 🔎 Analyst Highlights (RAMS & Pillar Scores)

#### Strongest Stocks  
| Ticker | RAMS | Trend | Momentum | Breakout | Volume | RSI | Signal |
|--------|------|-------|----------|----------|--------|-----|--------|
| **LLY** | 75.7 | 100 | 80 | 67 | 50 | 69.9 | **HOLD** |
| **TSLA**| 71.5 | 75 | 80 | 100 | 50 | 61.3 | **WAIT** |
| **COST**| 66.0 | 100 | 60 | 67 | 25 | 60.0 | **HOLD** |

#### Weakest Stocks  
| Ticker | RAMS | Trend | Momentum | Breakout | Volume | RSI | Signal |
|--------|------|-------|----------|----------|--------|-----|--------|
| **AMD** | 13.5 | 0 | 0 | 0 | 0 | 43.7 | **WAIT** |
| **COIN**| 17.3 | 0 | 20 | 0 | 25 | 46.2 | **WAIT** |
| **CAT** | 22.8 | 0 | 40 | 33 | 0 | 41.0 | **WAIT** |
| **JPM** | 24.8 | 25 | 20 | 0 | 25 | 47.0 | **WAIT** |

---

### ⚠️ Key Warnings & Observations  

- **LLY RSI 69.9** – edging the overbought zone; watch for a short‑term pull‑back.  
- **Low Volume Alerts** – COST, PLTR, CAT, COIN, AMD all have volume scores ≤25, indicating fragile price moves.  
- **Breakout Deficiency** – XOM shows a breakout score of 0 despite a decent trend (75) and volume (75); upside may be limited.  
- **Position‑Specific Risk** – XOM is the only losing position, down ~1% on the trade; consider tightening stop‑loss or scaling out.  

---

### 📌 Outlook & Tactical Takeaways  

1. **Defensive Tilt:** In a bear regime, prioritize high‑RAMS, high‑trend stocks (LLY, TSLA, COST).  
2. **Profit‑Take on LLY:** Near‑overbought RSI suggests locking in part of the 6.9% gain.  
3. **Monitor XOM:** Small loss but exposure is sizable (≈12% of portfolio). Evaluate stop‑loss or hedge.  
4. **Avoid Weak Scores:** Stay clear of AMD, COIN, CAT, JPM until their RAMS improve and volume picks up.  
5. **Liquidity Management:** With $383k buying power, consider adding to strong positions on pull‑backs rather than chasing weak stocks.  

*Overall, the portfolio is modestly positive, but the bear market context calls for disciplined risk management and a focus on the few high‑conviction, high‑momentum names.*