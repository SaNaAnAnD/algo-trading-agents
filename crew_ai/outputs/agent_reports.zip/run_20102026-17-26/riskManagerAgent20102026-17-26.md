# Risk Manager Agent

## Proposed orders
1. BUY 21 TSLA @ limit 375.83 (RAMS 75.3) - RAMS 75.3 above buy level

## Review
- **Order 1: BUY 21 TSLA @ limit 375.83** – **REJECTED** – RAMS score of 75.3 is well above the buy threshold, indicating an extremely overbought condition, which is especially risky in the current bear market regime.