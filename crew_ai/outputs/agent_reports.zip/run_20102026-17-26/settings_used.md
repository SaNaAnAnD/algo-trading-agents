# Settings Used

Timestamp: 2026-10-20T17:26:54
Flags: --auto
Model: groq/openai/gpt-oss-120b
Stocks: TSLA, AMD, PLTR, COIN, MSFT, JPM, LLY, XOM, COST, CAT
Regime: BEAR
Buy threshold: 75

## Settings
MCP_URL: http://localhost:8001/mcp
LLM_MODEL: groq/openai/gpt-oss-120b
TARGET_INVESTED: 0.95
STOP_ATR: 2.5
TAKE_PROFIT_ATR: 3.0
LIMIT_BUFFER: 0.003
MAX_RPM: 2
NEWS_HEADLINES: 3
EXTENDED_HOURS: True
LLM_RETRIES: 5
