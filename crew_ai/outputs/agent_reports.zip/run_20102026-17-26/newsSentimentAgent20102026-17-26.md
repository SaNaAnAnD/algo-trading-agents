# News Sentiment Agent

## Headlines
TSLA: Tesla Analyst Raises Revenues Estimates Ahead Of Q3 Results | 408x Oversubscribed AI IPO Crashes 32%—Democratic Sweep Prospects Trigger Selling in Data Center Stocks | 'A Surprisingly Large Amount Of Your Investment Is Divided Across Just 7 Companies' — Former Investment Banker Says She's Changing How She Invests
AMD: AMD And Intel Collaborate To Combine x86 CPU Optimization Work For PyTorch In oneDNN, Open-Source Deep Learning Library Governed By Unified Acceleration Foundation | Wedbush Reiterates Outperform on Advanced Micro Devices, Maintains $600 Price Target | Why Is AMD Stock Surging on Monday?
PLTR: Michael Burry Sees a 2000-Style Rotation Out of the Market's Winners | PLTR Stock’s Biggest Risk Isn’t Slowing Growth, but Its Price, Analyst Warns — Valuation Already Bakes In ‘Years of Exceptional Execution’ | Cathie Wood Buys $8.1 Million of CoreWeave Stock as Goldman Sachs Upgrades, Ark Invest Sells Palantir Stock
COIN: JPMorgan Taps Ethereum for JPM Coin as Tokenization Race Heats Up | Trump Gave Crypto What It Wanted: Is He Also Its Biggest Problem? | Coinbase Strikes Marqeta Deal but COIN Loses 3%
MSFT: 408x Oversubscribed AI IPO Crashes 32%—Democratic Sweep Prospects Trigger Selling in Data Center Stocks | Michael Burry Sees a 2000-Style Rotation Out of the Market's Winners | 'A Surprisingly Large Amount Of Your Investment Is Divided Across Just 7 Companies' — Former Investment Banker Says She's Changing How She Invests
JPM: Energy Only Sector Lower In Tuesday Trading As Defensives Lead | If You Invested $1000 In JPMorgan Chase Stock 10 Years Ago, You Would Have This Much Today | What's Going On With Exxon Stock On Monday?
LLY: Energy Only Sector Lower In Tuesday Trading As Defensives Lead | Swiss Pharma Giant Roche Suspends German Capital Commitments Amid Dispute Over Drug Discounts | Eli Lilly’s Omvoh Shows 1-Year Phase 3 Results for Kids with Ulcerative Colitis
XOM: Energy Only Sector Lower In Tuesday Trading As Defensives Lead | Chevron, ExxonMobil Stocks Hit 52-Week Highs as Fresh US-Israel Threats Against Iran Push Brent Crude to 5-Month Highs | Barclays Maintains Overweight on ExxonMobil Holdings, Raises Price Target to $200
COST: Walmart Bundles Its Walmart+ and Sam’s Club Plus Memberships Together For $120/Year | Tigress Financial Maintains Buy on Costco Wholesale, Raises Price Target to $1250 | This House of Representative Just Sold Up To $65K In AutoZone Stock
CAT: Caterpillar Investing $10M In Its North Carolina Operations | Oppenheimer Maintains Outperform on Caterpillar, Lowers Price Target to $1009 | Nasdaq 100 Drops 1% on Hot CPI, SOXX Falls 7th Day: Stock Market Today

## Scores
```json
{
  "TSLA": 0.5,
  "AMD": 0.8,
  "PLTR": -0.6,
  "COIN": -0.3,
  "MSFT": -0.2,
  "JPM": 0.5,
  "LLY": 0.4,
  "XOM": 0.6,
  "COST": 0.3,
  "CAT": 0.2
}
```
