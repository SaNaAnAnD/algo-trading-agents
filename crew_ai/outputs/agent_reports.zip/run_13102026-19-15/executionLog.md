# Execution Log

- [1/1] SELL 10 LLY @ limit 1156.18 (RAMS 27.0, stop-loss 1137.80) - stop-loss hit - OrderStatus.PENDING_NEW
