# Market Data Agent

## 📊 Account Snapshot  
| Metric | Value |
|--------|-------|
| **Cash** | **$26,015.61** |
| **Buying Power** | **$311,627.23** |
| **Portfolio Value / Equity** | **$100,145.89** |
| **Total Unrealized P/L** | **+$145.91** |

### Position Highlights  
| Symbol | Qty | Avg. Entry | Current | Unrealized P/L | % P/L |
|--------|-----|------------|---------|----------------|-------|
| **AAPL** | 1 | $337.81 | $342.57 | +$4.76 | +1.41% |
| **COST** | 12 | $958.79 | $957.61 | –$14.16 | –0.12% |
| **JPM** | 35 | $334.67 | $333.97 | –$24.50 | –0.21% |
| **LLY** | 10 | $1,183.00 | $1,158.98 | –$240.20 | –2.03% |
| **MSFT** | 22 | $540.06 | $545.94 | +$129.34 | +1.09% |
| **PLTR** | 72 | $206.38 | $208.05 | +$120.24 | +0.81% |
| **XOM** | 69 | $171.84 | $174.31 | +$170.43 | +1.44% |

## 🌐 Market Regime  
- **SPY indicates a BULL market** – momentum is broadly positive, risk‑on sentiment prevailing.

## 🔎 Analyst Pillar Summary (RAMS Scores)  
- **Strongest / Buy Candidates**: **XOM**, **MSFT**, **PLTR** – high trend (100), solid momentum & volume, breakout scores strong.  
  - *Watch*: XOM RSI 75.5 (near over‑bought) – consider partial profit or tighter stops.  
- **Moderately Strong / Hold**: **COST** – perfect trend but weaker momentum; still healthy.  
- **Weak / Sell / Reduce**: **LLY**, **TSLA**, **CAT** – low RAMS, oversold RSI, no breakout momentum.  
- **Caution**: **JPM**, **AMD**, **COIN** – decent trend but low volume or breakout scores; hold with watch on volume.

## 📈 Take‑aways for the Desk  
1. **Capitalize on the bullish backdrop** by adding to the top‑tier leaders (XOM, MSFT, PLTR) if buying power permits.  
2. **Trim exposure** to the weakest pillar stocks (LLY, TSLA, CAT) – they are oversold and lack breakout support.  
3. **Monitor XOM’s RSI** closely; a pull‑back could be imminent.  
4. **Maintain a watchlist** on JPM, AMD, COIN for potential volume‑driven moves; they may swing on news or earnings.  
5. **Overall portfolio health** is positive with a modest unrealized gain (+$146) and ample buying power for selective opportunistic entries.