# Risk Manager Agent

## Proposed orders
1. SELL 10 LLY @ limit 1156.18 (RAMS 27.0) - stop-loss hit

## Review
- **SELL 10 LLY @ limit 1156.18** – **APPROVED**: The order follows the predefined stop‑loss rule, trims a losing healthcare position, does not create sector concentration, and LLY has a positive news score (0.6). No risk flags present.