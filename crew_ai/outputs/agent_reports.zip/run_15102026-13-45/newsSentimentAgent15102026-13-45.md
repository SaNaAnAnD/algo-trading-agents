# News Sentiment Agent

## Headlines
TSLA: 'Tesla Readies Flying Car Demo To Pump Up Sluggish Auto Business; Planning To Unveil Its Long-Promised New Roadster Sports Car Thursday In Texas, Reviving And Refreshing A Model That Tesla Stopped Producing More Than A Decade Ago' - Bloomberg News | GLJ Research Reiterates Sell on Tesla, Maintains $24.86 Price Target | When Can You Buy a Tesla Cybercab? Investors Press Elon Musk on Robotaxis, HW3 FSD and More Ahead of TSLA's Q3 Earnings
AMD: Why Is AMD Stock Falling on Wednesday? | ASML Says AI Boom Is Boosting Pricing Power as Chipmakers Agree to Pay More | Nasdaq 100 Drops 1% on Hot CPI, SOXX Falls 7th Day: Stock Market Today
PLTR: Customers Bancorp Announces Collaboration With Palantir To Deploy AI Software For Deposit Account Opening; Terms Not Disclosed | Surf Air Mobility Signs Definitive Agreement With Flying Zebra For OperatorOS, Surf Air Mobility's SurfOS Flight Operations Software For Part 135 Operators Powered By Palantir | Cathie Wood Buys $12.4 Million Of CoreWeave Stock As Analyst Warns Of Equity Wipeout, Ark Sells Palantir Shares
COIN: 'Taiwan Blocks Coinbase, Kalshi Over Suspected Election Bets' - Bloomberg | Coinbase Investigates Possible NEAR Network Send And Receive Delays For Some Users, Says Funds Safe; Buys, Sells, Fiat Withdrawals And Deposits Unaffected | DriveWealth to Integrate Ripple as Evernorth Deploys XRP Treasury
MSFT: FTC Spokesman Says President Trump Task Force On AI To Meet Thursday | TD Cowen Maintains Buy on Microsoft, Raises Price Target to $625 | Politico Reported Microsoft President Warned White House Against Crackdown On Skilled Immigration
JPM: JPMorgan, Bank of America, Wells Fargo Among 9 Banks Accused of Political, Religious Debanking by OCC | Potential $100 Billion Anthropic IPO Could Boost Wall Street Banks: Which ETFs Stand to Benefit? | JPMorgan’s Chase Holds AI Scam Awareness Event Streamed To ~700 Branches
LLY: Lilly Reports Omvoh Achieved Multiple Treatment Goals Simultaneously At One Year In IBD Studies | Adlai Nortye Group enters Clinical Trial Collaboration And Supply Agreements With Eli Lilly And Merck KGaA For The ERBITUX Anti-EGFR Antibody | QUICK SPARK: This New ETF Goes Beyond Eli Lilly, Novo Nordisk and Targets the Peptide Boom
XOM: 8 Of 11 Sectors Fall Wednesday As Defensives Lead | Guyana May Scale Back LNG Plans As Exxon Needs More Gas For Its Wells, Sources Say | Cyclicals Lead Sectors In Tuesday Trading As Health Care Trails
COST: Why Is Costco (COST) Stock Trending After Hours? | 8 Of 11 Sectors Fall Wednesday As Defensives Lead | 9 Of 11 Sectors Rise Friday As Real Estate Leads
CAT: Oppenheimer Maintains Outperform on Caterpillar, Lowers Price Target to $1009 | Nasdaq 100 Drops 1% on Hot CPI, SOXX Falls 7th Day: Stock Market Today | What's Going On With Caterpillar Stock Wednesday?

## Scores
```json
{
  "TSLA": 0.2,
  "AMD": -0.3,
  "PLTR": 0.3,
  "COIN": -0.5,
  "MSFT": 0.4,
  "JPM": -0.2,
  "LLY": 0.5,
  "XOM": -0.3,
  "COST": 0.1,
  "CAT": -0.2
}
```
