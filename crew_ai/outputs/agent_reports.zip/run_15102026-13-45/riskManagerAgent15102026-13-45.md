# Risk Manager Agent

## Proposed orders
1. SELL 1 COST @ limit 994.74 (RAMS 73.8) - take half profit
2. SELL 4 XOM @ limit 176.05 (RAMS 67.9) - take half profit

## Review
- **Order 1 – SELL 1 COST @ limit 994.74** – **APPROVED** – Reason: Takes partial profit on a modest consumer‑staples position, keeps sector exposure within limits, and the news score for COST is neutral‑positive (0.1) in a bear regime.

- **Order 2 – SELL 4 XOM @ limit 176.05** – **APPROVED** – Reason: Reduces exposure to energy where the news sentiment is negative (‑0.3) and the market is bearish, while still preserving diversification and locking in profit on part of the holding.