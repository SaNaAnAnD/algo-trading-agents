# Execution Log

- [1/2] SELL 1 COST @ limit 994.74 (RAMS 73.8, stop-loss 982.48) - take half profit - OrderStatus.PENDING_NEW
- [2/2] SELL 4 XOM @ limit 176.05 (RAMS 67.9, stop-loss 174.06) - take half profit - OrderStatus.PENDING_NEW
