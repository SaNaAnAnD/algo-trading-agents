# Settings Used

Timestamp: 2026-10-12T18:37:07
Flags: --dry-run
Model: groq/llama-3.3-70b-versatile
Stocks: TSLA, AMD, PLTR, COIN, MSFT, JPM, LLY, XOM, COST, CAT
Regime: BULL
Buy threshold: 65

## Settings
MCP_URL: http://localhost:8001/mcp
LLM_MODEL: groq/llama-3.3-70b-versatile
TARGET_INVESTED: 0.95
STOP_ATR: 2.5
TAKE_PROFIT_ATR: 3.0
LIMIT_BUFFER: 0.003
MAX_RPM: 20
NEWS_HEADLINES: 3
EXTENDED_HOURS: True
LLM_RETRIES: 3
