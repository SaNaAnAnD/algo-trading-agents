# News Sentiment Agent

## Headlines
TSLA: Tesla Is Up 10% — So Why Are These 2X TSLA ETFs Heading in the Opposite Direction? | Goldman Says Tesla’s Robotaxi, Optimus Outlook Will Matter More Than Q3 Earnings. Here’s the Bar for Oct. 21 | Maye Musk Praises Elon Musk’s ‘Safety First’ Focus After Tesla Owner Says EV Saved Him and Son in Crash
AMD: Credo Technology Group To Unveil Its OmniConnect Weaver Memory Fanout Gearbox On AMD Versal AI Edge Series Gen 2 Adaptive SoC Evaluation Board | nVent And AMD Collaborate To Bring Rack-Level Cooling To AMD Helios Rackscale Solution | Fermi Inks Credit Support Agreement With AMD To Support Lease For Phase 1 Of Its Project Matador Energy And AI Buiildout In Texas
PLTR: Ondas Wants to Run Pentagon AI with Palantir-Powered Regna AI | Ondas Takes Its Palantir Partnership Deeper With New Sovereign AI Company | Quantum Computing Is Eyeing a 2028 Breakthrough, 2 ETFs Could Capture It
COIN: Bitmine Immersion Technologies Reports $16.2B In Crypto + Total Cash & Marketable Securities + Moonshots Holdings; Crypto Holdings Comprise Of 6,028,946 ETH At $2,544 Per ETH As Of Oct. 11 | Bitcoin, XRP Get the Spotlight—Could These 5 Altcoins Be Next? | EXCLUSIVE: Treasury Yields at 8%? This CEO Sees a Big Bitcoin ETF Opportunity
MSFT: Reported October 12, Microsoft Executive Charles Lamanna Seen As Potential Successor To CEO Satya Nadella - The Information | Marvell Technology, Microsoft, Oracle Collaborate For Open Compute Project To Standardize NIST FIPS 140-3 Integrated HSM For Cloud, Hyperscale Data Center Infrastructure | SpaceX's Wireless Push Sparks Wall Street Skepticism: Is the Stock Getting Ahead of Itself?
JPM: Transcript: JPMorgan Chase Q3 2026 Earnings Conference Call | JPMorgan CEO Jamie Dimon Sounds Alarm on Inflation, Rising Rates and Economic Risks | JPMorgan CFO Says Says Corporate Credit Outlook Is Currently Pretty Stable
LLY: U.K. Medicines And Healthcare Products Regulatory Agency Authorizes Eli Lilly's Onswik For Adults With Type 2 Diabetes | Prelude Therapeutics Enters Clinical Trial Collaboration And Supply Agreement With Eli Lilly For Supply Of Its CDK4/6 Kinase Inhibitor, Abemaciclib And Its Oral Estrogen Receptor Antagonist Imlunestrant | RBC Capital Reiterates Outperform on Eli Lilly, Maintains $1500 Price Target
XOM: 9 Of 11 Sectors Rise Monday As Cyclicals Lead | Iran Offers to Broker Saudi-Houthi Talks as Riyadh Vows an ‘Equally Serious’ Response to Deadly Airport Strikes: Report | Exxon Mobil Rejects Proposed $5.2 Billion Kashagan Fine Settlement: Report
COST: 9 Of 11 Sectors Rise Friday As Real Estate Leads | RBC Capital Reiterates Sector Perform on Costco Wholesale, Maintains $1000 Price Target | The $90 Social Security Payment Is a Tiny Stimulus. The Retiree Economy Is a Market Giant
CAT: Citigroup Maintains Buy on Caterpillar, Lowers Price Target to $950 | 8 Industrials Stocks Whale Activity In Today’s Session | Stock Market Today: S&P 500, Dow Jones, Nasdaq 100 Futures Decline as Pentagon Prepares for Potential Military Strikes on Iran — APLD, LEVI, MU in Focus (UPDATED)

## Scores
```json
{
  "TSLA": 0.6,
  "AMD": 0.5,
  "PLTR": 0.4,
  "COIN": 0.1,
  "MSFT": 0.2,
  "JPM": -0.2,
  "LLY": 0.8,
  "XOM": 0.3,
  "COST": 0.5,
  "CAT": -0.3
}
```
