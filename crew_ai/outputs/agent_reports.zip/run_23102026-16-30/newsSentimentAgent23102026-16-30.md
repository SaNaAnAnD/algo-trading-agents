# News Sentiment Agent

## Headlines
TSLA: Elon Musk's Tesla-SpaceX Merger Could Face Antitrust Hurdles Over Starlink Access, ‘Vertical Foreclosure’, Former DOJ Official Warns | Tesla Wants To Learn the Roads With AI — Google Maps, Take Note | Tesla Cancels Cybertruck Production Plans for Australia and New Zealand
AMD: Nvidia’s China Market Has Effectively Vanished: ‘Every Restriction Also Gives Chinese Suppliers a Larger Captive Market,’ Says Shay Boloor | Nasdaq Records Worst Session Since June: Investor Sentiment Weakens, Greed Index Moves To ‘Extreme Fear’ Zone | SOAR AI, Inc. Announces Contracted GPU Deployments Featuring AMD Instinct™ Accelerators
PLTR: Dan Ives Says Palantir and Snowflake Are Nearing the 'End of That Gap' Between AI CapEx and True Monetization, Warns Wall Street Is Underestimating Tech Earnings by Up to 25% | Michael Burry Shares Chilling Song on AI: 'Watching Trillion-Dollar Monuments Become Obsolete' | Citigroup Maintains Buy on Palantir Technologies, Raises Price Target to $250
COIN: Autonomous Research Adjusts Price Target on Coinbase Global | Bitcoin to $1 Million? Don't Expect 100X Returns Anymore, Dan Tapiero Says | Ripple Sees a $100 Million Opportunity for Banks—What’s in It for XRP?
MSFT: Blackstone's $2.3 Billion CoreWeave Bet Sparked a Trillion-Dollar AI Lending Boom | 8 Of 11 Sectors Fall In Friday Trading As Energy Leads | Microsoft's Earnings Are Days Away: Here’s What Investors Need to Know
JPM: Bitcoin’s Rally Hits 3 Roadblocks: Can Bulls Shake Off ‘Black October’? | JPMorgan Chase Files TR-1 Notification for Bodycote Plc | JPMorgan Chase Reports Change in Major Holding of Intertek Group PLC
LLY: More Americans Now Take GLP-1 Drugs for Weight Loss Than Diabetes as Food, Alcohol and Apparel Habits Shift, Survey Finds | Eli Lilly and Company Breaks Ground on $5B Integrated Manufacturing Site in Virginia | Defensives Lead Sectors In Thursday Trading As Growth Trails
XOM: ExxonMobil Joliet Refinery Experiences Operational Disruption | 'Qatar Scours for More LNG to Boost Supply Outside Middle East' - Bloomberg Exclusive | Shell and ExxonMobil Joint Venture Infineum Explores $8 Billion Sale
COST: Urban Remedy Launches Chocolate Protein Collagen Shake at Select Costco Warehouses | Walmart’s Best Month Since 1999 Leads a Record Staples Rally: Is This a Warning Sign? | IQBAR Launches Indulgent Protein Bites at Costco
CAT: 8 Of 11 Sectors Fall In Friday Trading As Energy Leads | GE Vernova Stock Rebounds, AI Sell-Off Gives Way To Earnings Focus | AI Sell-Off Spreads to Industrials: Caterpillar, GE Vernova, Vertiv Trapped in Bear Market

## Scores
```json
{
  "TSLA": -0.4,
  "AMD": 0.2,
  "PLTR": 0.5,
  "COIN": -0.1,
  "MSFT": 0.0,
  "JPM": 0.0,
  "LLY": 0.35,
  "XOM": -0.2,
  "COST": 0.2,
  "CAT": -0.4
}
```
