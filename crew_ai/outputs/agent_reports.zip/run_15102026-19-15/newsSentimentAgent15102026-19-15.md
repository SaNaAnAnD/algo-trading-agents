# News Sentiment Agent

## Headlines
TSLA: Anthropic Needs Nearly $2.7B in Additional Monthly Revenue to Reach $100B Run Rate by Year-End | Michael Burry's 'Red October' Warning: Why QQQ and SMH Could Face More Pain | 10 Consumer Discretionary Stocks Whale Activity In Today’s Session
AMD: Rate Pressure vs. AI Demand: Rising Treasury Yields Trigger Nvidia, AMD Slump | AI Financing Fears Hammer Chip Stocks: These 2 ETFs Are Cashing In on the Sell-Off | Why Is AMD Stock Falling on Wednesday?
PLTR: Mizuho Maintains Outperform on Palantir Technologies, Raises Price Target to $245 | Live On CNBC, Josh Brown Hosts Segment Titled "Josh's Best Stocks In The Market: Palantir Technologies" | Surf Air Mobility Expands Palantir-Powered AI Push With Fifth Aviation Software Deal
COIN: 'Taiwan Blocks Coinbase, Kalshi Over Suspected Election Bets' - Bloomberg | Coinbase Investigates Possible NEAR Network Send And Receive Delays For Some Users, Says Funds Safe; Buys, Sells, Fiat Withdrawals And Deposits Unaffected | DriveWealth to Integrate Ripple as Evernorth Deploys XRP Treasury
MSFT: Anthropic Needs Nearly $2.7B in Additional Monthly Revenue to Reach $100B Run Rate by Year-End | 'OpenAI’s Accelerates Ad Sprint With Meta Hires, Slashed Prices' - The Information | Michael Burry's 'Red October' Warning: Why QQQ and SMH Could Face More Pain
JPM: Citigroup Maintains Neutral on JPMorgan Chase, Lowers Price Target to $350 | Why Is SoFi Stock Climbing on Thursday? | 'JPMorgan Mulls Revival of Software Debt Deal Lenders Had Shunned' - Bloomberg Exclusive
LLY: Eli Lilly Says New Drug Drives Comprehensive Disease Control in Ulcerative Colitis Patients | Defensives Lead Sectors In Thursday Trading As Technology Trails | Here’s How Much You Would Have Made Owning Eli Lilly Stock In The Last 20 Years
XOM: Morgan Stanley Maintains Overweight on ExxonMobil Holdings, Raises Price Target to $185 | Defensives Lead Sectors In Thursday Trading As Technology Trails | 8 Of 11 Sectors Fall Wednesday As Defensives Lead
COST: This House of Representative Just Sold Up To $65K In AutoZone Stock | Why Is Costco (COST) Stock Trending After Hours? | 8 Of 11 Sectors Fall Wednesday As Defensives Lead
CAT: Caterpillar Investing $10M In Its North Carolina Operations | Oppenheimer Maintains Outperform on Caterpillar, Lowers Price Target to $1009 | Nasdaq 100 Drops 1% on Hot CPI, SOXX Falls 7th Day: Stock Market Today

## Scores
```json
{
  "TSLA": -0.2,
  "AMD": -0.7,
  "PLTR": 0.6,
  "COIN": -0.5,
  "MSFT": -0.1,
  "JPM": -0.3,
  "LLY": 0.7,
  "XOM": 0.6,
  "COST": 0.2,
  "CAT": 0.3
}
```
