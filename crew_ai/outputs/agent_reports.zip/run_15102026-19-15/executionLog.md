# Execution Log

- [1/1] SELL 2 LLY @ limit 1261.90 (RAMS 82.0, stop-loss 1236.72) - take half profit - OrderStatus.PENDING_NEW
