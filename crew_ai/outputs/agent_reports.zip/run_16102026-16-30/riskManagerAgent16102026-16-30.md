# Risk Manager Agent

## Proposed orders
1. SELL 1 LLY @ limit 1259.44 (RAMS 81.7) - take half profit
2. SELL 1 XOM @ limit 176.64 (RAMS 70.2) - take half profit

## Review
- **Order 1 – SELL 1 LLY @ limit 1259.44** – **APPROVED** – Reduces exposure in a bullish‑news health‑care stock during a bear regime; no sector concentration issue.
- **Order 2 – SELL 1 XOM @ limit 176.64** – **APPROVED** – Takes partial profit on energy exposure; news is neutral‑positive and the portfolio remains well‑diversified.