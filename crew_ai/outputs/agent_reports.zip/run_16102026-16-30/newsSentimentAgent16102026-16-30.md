# News Sentiment Agent

## Headlines
TSLA: Why Is Applied Digital Stock Falling Friday? | Slovakia Approves Tesla Full Self-Driving System | Gary Black Warns Tesla Bulls Against Hyping SpaceX Merger, Says Roadster’s Brand Impact Could Outweigh Earnings
AMD: What's Going On With Fermi Stock Friday? | Taiwan Semiconductor Holds the Cards As NVIDIA, Apple and AMD Battle for Limited AI Chip Capacity | Rate Pressure vs. AI Demand: Rising Treasury Yields Trigger Nvidia, AMD Slump
PLTR: Trump’s $330 Million White House Ballroom Donor List Reveals Nvidia, Apple and Google Among Top Tech Contributors: Report (UPDATED) | Cathie Wood Buys $13.4 Million of CoreWeave Stock as Jensen Huang Says ‘Strength Is Improving Every Day,’ Ark Trims Amazon and Palantir | Mizuho Maintains Outperform on Palantir Technologies, Raises Price Target to $245
COIN: Looking Beyond Bitcoin? Analysts See Bigger Opportunities in These 5 Altcoins | Marqeta Collaborates With Coinbase To Bring Stablecoin-Backed Cards To Both Crypto-Native And Non-Crypto Firms | Coinbase Says Users May Face Delayed Sends On TON Network; Receives, Buys, Sells, Fiat Withdrawals And Deposits Not Affected, Funds Safe
MSFT: 9 Of 11 Sectors Rise In Friday Trading As Cyclicals Lead | Rep. David Taylor Has Bought Up to $45K Worth Of AT&T Stock: Here’s What You Should Know | NiSource Lands Major Microsoft Power Deal
JPM: 9 Of 11 Sectors Rise In Friday Trading As Cyclicals Lead | Trump’s $330 Million White House Ballroom Donor List Reveals Nvidia, Apple and Google Among Top Tech Contributors: Report (UPDATED) | GameStop CEO Ryan Cohen Warns Humans Could Attack Smarter Robots — ‘Whether That Ends Up Being World War III, I Don’t Know’
LLY: Eli Lilly's GLP-1 Pill Wins Key European Backing for Obesity and Diabetes | 9 Of 11 Sectors Rise In Friday Trading As Cyclicals Lead | Eli Lilly Receives EMA CHMP Positive Opinion Recommending Marketing Authorization For Foundayo For Treatment Of Type 2 Diabetes Mellitus And For Weight Management
XOM: ExxonMobil Sees $4.5 Billion Boost from Higher Refining Margins | Here’s How Much You Would Have Made Owning ExxonMobil Holdings Stock In The Last 5 Years | ExxonMobil Q3 Adjusting Items Include Estimated Timing Effects Of -$2.50B
COST: Tigress Financial Maintains Buy on Costco Wholesale, Raises Price Target to $1250 | This House of Representative Just Sold Up To $65K In AutoZone Stock | Why Is Costco (COST) Stock Trending After Hours?
CAT: Caterpillar Investing $10M In Its North Carolina Operations | Oppenheimer Maintains Outperform on Caterpillar, Lowers Price Target to $1009 | Nasdaq 100 Drops 1% on Hot CPI, SOXX Falls 7th Day: Stock Market Today

## Scores
```json
{
  "TSLA": 0.2,
  "AMD": -0.6,
  "PLTR": 0.1,
  "COIN": 0.4,
  "MSFT": 0.5,
  "JPM": 0.2,
  "LLY": 0.8,
  "XOM": 0.5,
  "COST": 0.4,
  "CAT": 0.2
}
```
