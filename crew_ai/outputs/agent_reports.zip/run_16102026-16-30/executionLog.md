# Execution Log

- [1/2] SELL 1 LLY @ limit 1259.44 (RAMS 81.7, stop-loss 1234.11) - take half profit - OrderStatus.PENDING_NEW
- [2/2] SELL 1 XOM @ limit 176.64 (RAMS 70.2, stop-loss 174.58) - take half profit - OrderStatus.PENDING_NEW
