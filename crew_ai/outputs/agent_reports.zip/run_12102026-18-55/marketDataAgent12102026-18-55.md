# Market Data Agent

```markdown
# 📊 Market Summary (Bullish Regime)

**Market Regime:** **BULL** (SPY indicates a continued up‑trend)  

## 💰 Account Snapshot
| Metric            | Value |
|-------------------|-------|
| **Cash**          | $99,662.18 |
| **Buying Power**  | $399,600.58 |
| **Portfolio Value** | $100,002.13 |
| **Equity**        | $100,002.13 |

## 📈 Open Position
| Symbol | Qty | Avg. Entry | Current | Market Value | Unrealized P/L | % P/L |
|--------|-----|------------|---------|--------------|----------------|-------|
| **AAPL** | 1 | $337.81 | $339.95 | $339.95 | **+$2.14** | **+0.63%** |

*Small profit on a single‑share tech position – consistent with the overall bullish tone.*

## 🔝 Strongest Stocks – **BUY** Signals
| Symbol | RAMS | Trend | Momentum | Volume | Breakout | RSI | Note |
|--------|------|-------|----------|--------|----------|-----|------|
| **COST** | 82.7 | 100 | 80 | 75 | 100 | **72.9** | Near overbought – watch for short‑term pull‑backs. |
| **MSFT** | 82.7 | 100 | 80 | 75 | 100 | 63.2 | Solid uptrend, neutral RSI. |
| **XOM**  | 75.7 | 100 | 80 | 50 | 67 | **68.4** | High RSI, monitor for correction. |
| **JPM**  | 75.2 | 75  | 80 | 75 | 100 | 65.1 | Strong breakout, healthy volume. |
| **PLTR** | 72.4 | 100 | 80 | 50 | 34 | 66.8 | Trend & momentum strong; breakout weaker. |

## ⚠️ Weakest Stocks – **WAIT / NEUTRAL** Signals
| Symbol | RAMS | Trend | Momentum | Volume | Breakout | RSI | Concern |
|--------|------|-------|----------|--------|----------|-----|----------|
| **AMD** | 15.0 | 25 | 0 | 0 | 0 | 25.0 | Oversold but no momentum/volume. |
| **CAT** | 19.5 | 0  | 40 | 0 | 0 | 40.7 | No clear trend, thin trading. |
| **COIN**| 22.8 | 0  | 40 | 0 | 33 | 45.8 | Weak breakout, low volume. |
| **TSLA**| 32.2 | 50 | 20 | 25 | 0 | 47.8 | Low momentum, no breakout. |

## 🚨 Red Flags & Watch‑Points
- **RSI > 70:** COST (72.9) – potential short‑term pull‑back. XOM (68.4) is close to overbought.
- **Weak Volume:** TSLA, COIN, CAT, AMD – thin trading may cause erratic moves.
- **Breakout Deficiencies:** TSLA, CAT, AMD (score 0); PLTR (34) – limited breakout strength.
- **Low Momentum:** TSLA (20) and AMD (0) – price acceleration stalled.

## 📌 Takeaway
The market remains in a **bullish** phase, supporting long‑biased strategies. Prioritize the top‑ranked BUY candidates (COST, MSFT, XOM, JPM, PLTR) while keeping a tight eye on overbought conditions for COST and XOM. Maintain a defensive stance on the weak‑signal symbols until volume, momentum, or breakout patterns improve. The modest gain in AAPL aligns with the overall positive sentiment, and the account retains ample buying power for new positions in the highlighted opportunities.