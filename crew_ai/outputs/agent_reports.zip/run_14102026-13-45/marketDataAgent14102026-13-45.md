# Market Data Agent

## 📊 Market Regime  
- **SPY indicates a BEAR market** – defensive positioning is favored.  
- Technical RAMS scores highlight only a few stocks with relative strength (XOM, LLY, COST, PLTR).  

## 📰 Key Analyst & Technical Take‑aways  
| Symbol | RAMS | Trend | Momentum | Volume | Breakout | RSI | Analyst Note |
|--------|------|-------|----------|--------|----------|-----|--------------|
| **XOM** | 73.0 | 100 | 60 | 50 | 100 | **76.7** (overbought) | Strong trend but watch for profit‑taking. |
| **LLY** | 71.6 | 75 | 100 | 100 | 66 | 66.9 | Robust across all factors, still below overbought. |
| **COST** | 69.7 | 100 | 60 | 50 | 67 | 68.6 | Nearing overbought; good trend, moderate momentum. |
| **PLTR** | 66.4 | 100 | 60 | 50 | 34 | 58.9 | Neutral RSI, solid trend, breakout weakening. |
| **JPM** | 22.0 | 25 | 0 | 25 | 33 | 36.2 | Weak momentum & breakout – defensive sell. |
| **TSLA** | 25.8 | 50 | 0 | 0 | 33 | 29.2 | Very low volume, no momentum – avoid. |
| **AMD** | 28.5 | 25 | 20 | 50 | 0 | 37.4 | Low momentum, no breakout. |
| **CAT** | 18.3 | 0 | 0 | 33 | 33 | 30.7 | Extremely weak – stay out. |
| **MSFT** | – | – | – | **0** | 34 | – | Zero volume flag – risk of slippage. |

**Red Flags**  
- **XOM RSI > 70** → consider tightening stops or taking partial profits.  
- **Zero/very low volume** on MSFT, TSLA → ill‑liquid moves.  
- Breakout scores ≤ 35 for PLTR, JPM, TSLA, CAT signal limited upside in a bear market.  

## 💼 Account Snapshot (Paper‑Trading)  
| Metric | Value |
|--------|-------|
| **Cash** | $37,614.56 |
| **Buying Power** | $325,247.85 |
| **Portfolio Value / Equity** | $100,039.42 |
| **Total Unrealized P/L** | **+$71.11** (≈ 0.07% of equity) |

### Position Highlights
- **AAPL**: +$8.25 (2.44% gain) – small position, modest upside.  
- **COST**: +$49.32 (0.43% gain) – aligns with strong RAMS, consider scaling.  
- **MSFT**: +$60.84 (0.51% gain) – despite zero volume warning, still modest profit.  
- **PLTR**: +$96.88 (0.65% gain) – matches RAMS strength, could add on dips.  
- **XOM**: +$214.59 (1.81% gain) – overbought; monitor for pull‑back.  
- **JPM**: –$157.68 (‑1.35% loss) – weak RAMS, may trim or hedge.  

## 🎯 Actionable Outlook  
1. **Defensive Tilt** – Favor the four higher‑RAMS stocks (XOM, LLY, COST, PLTR) while respecting XOM’s overbought condition.  
2. **Trim Weak Positions** – Reduce exposure to JPM, TSLA, AMD, CAT; consider stop‑losses near recent lows.  
3. **Liquidity Caution** – Avoid adding to MSFT or TSLA until volume improves.  
4. **Cash Management** – With $37.6k cash and ample buying power, allocate modestly to LLY (not currently held) and add to COST/PLTR on pull‑backs, keeping overall portfolio beta low.  

*In a bear‑market environment, preserving capital and positioning in the few stocks showing relative strength while staying vigilant on overbought signals is the prudent strategy.*