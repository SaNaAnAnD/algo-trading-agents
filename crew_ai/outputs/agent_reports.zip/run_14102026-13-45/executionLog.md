# Execution Log

- [1/3] SELL 35 JPM @ limit 329.82 (RAMS 27.8, stop-loss 324.22) - RAMS 27.8 below sell level - OrderStatus.PENDING_NEW
- [2/3] SELL 34 XOM @ limit 174.40 (RAMS 75.3, stop-loss 172.49) - take half profit - OrderStatus.PENDING_NEW
- [3/3] BUY 9 LLY @ limit 1211.15 (RAMS 76.1, stop-loss 1178.23) - RAMS 76.1 above buy level - OrderStatus.PENDING_NEW
