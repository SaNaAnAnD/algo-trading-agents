# Technical Analyst Agent

| Symbol | RAMS | Trend | Momentum | Volume | Breakout | RSI | Signal |
|---|---|---|---|---|---|---|---|
| XOM | 73.0 | 100 | 60 | 50 | 100 | 76.7 | HOLD |
| LLY | 71.6 | 75 | 100 | 100 | 66 | 66.9 | WAIT |
| COST | 69.7 | 100 | 60 | 50 | 67 | 68.6 | HOLD |
| PLTR | 66.4 | 100 | 60 | 50 | 34 | 58.9 | HOLD |
| MSFT | 58.9 | 100 | 60 | 0 | 34 | 56.8 | HOLD |
| COIN | 49.9 | 25 | 80 | 50 | 34 | 51.5 | WAIT |
| AMD | 28.5 | 25 | 20 | 50 | 0 | 37.4 | WAIT |
| TSLA | 25.8 | 50 | 0 | 0 | 33 | 29.2 | WAIT |
| JPM | 22.0 | 25 | 0 | 25 | 33 | 36.2 | SELL |
| CAT | 18.3 | 0 | 0 | 50 | 33 | 30.7 | WAIT |

**Technical Analysis (Bear Market – Buy threshold 75)**  

**🔝 Strongest candidates (RAMS ≥ 65)**  
- **XOM – 73.0**  
  - Trend: 100, Momentum: 60, Volume: 50, Breakout: 100  
  - RSI 76.7 (overbought – see warnings)  
- **LLY – 71.6**  
  - Trend: 75, Momentum: 100, Volume: 100, Breakout: 66  
  - RSI 66.9 (still below overbought level)  
- **COST – 69.7**  
  - Trend: 100, Momentum: 60, Volume: 50, Breakout: 67  
  - RSI 68.6 (approaching overbought)  
- **PLTR – 66.4**  
  - Trend: 100, Momentum: 60, Volume: 50, Breakout: 34  
  - RSI 58.9 (neutral)  

**🔻 Weakest candidates (RAMS ≤ 30)**  
- **CAT – 18.3** – Trend 0, Momentum 0, Breakout 33, RSI 30.7 (very weak)  
- **JPM – 22.0** – Trend 25, Momentum 0, Volume 25, Breakout 33, RSI 36.2 (sell signal)  
- **TSLA – 25.8** – Trend 50, Momentum 0, Volume 0, Breakout 33, RSI 29.2 (weak volume & momentum)  
- **AMD – 28.5** – Trend 25, Momentum 20, Volume 50, Breakout 0, RSI 37.4 (low momentum, no breakout)  

**⚠️ Warnings & Red Flags**  
- **RSI > 70:** XOM (76.7) – overbought; consider profit‑taking or tighter stops.  
- **Very low or zero volume:** MSFT (0), TSLA (0) – price moves may be ill‑iquid; risk of slippage.  
- **Breakout scores near or below 35:** PLTR (34), MSFT (34), TSLA (33), JPM (33), CAT (33) – limited breakout strength in a bear regime.  
- **Momentum weakness:** AMD (20), TSLA (0), JPM (0) – lack of upward price pressure.  

**Take‑away:** In a bear market, only XOM, LLY, COST, and PLTR show relatively robust RAMS scores and trend strength. XOM’s high RSI warrants caution. The remaining symbols exhibit weak momentum, volume, or breakout characteristics and should be avoided or approached with defensive positioning.