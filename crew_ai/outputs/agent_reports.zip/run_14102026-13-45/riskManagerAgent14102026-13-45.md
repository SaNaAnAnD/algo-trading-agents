# Risk Manager Agent

## Proposed orders
1. SELL 35 JPM @ limit 329.82 (RAMS 27.8) - RAMS 27.8 below sell level
2. SELL 34 XOM @ limit 174.40 (RAMS 75.3) - take half profit
3. BUY 9 LLY @ limit 1211.15 (RAMS 76.1) - RAMS 76.1 above buy level

## Review
- **Order 1 – SELL 35 JPM @ limit 329.82** – **APPROVED**  
  *Reason:* Reduces exposure to the financial sector in a bear regime; JPM has a positive news score (+0.4) and no overbought signal, so the sale aligns with risk‑off positioning.

- **Order 2 – SELL 34 XOM @ limit 174.40** – **APPROVED**  
  *Reason:* Takes partial profit on the energy position while the sector faces negative news (XOM –0.2) and a bearish market outlook; reducing exposure is prudent.

- **Order 3 – BUY 9 LLY @ limit 1211.15** – **APPROVED**  
  *Reason:* Adds diversification into healthcare, a sector not currently represented in the portfolio; LLY has a strong positive news score (+0.6) and the purchase fits within available cash and buying power.