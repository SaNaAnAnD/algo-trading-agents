# News Sentiment Agent

## Headlines
TSLA: How To Trade SPY, QQQ, AAPL, MSFT, NVDA, GOOGL, META, And TSLA | Wall Street’s ‘Last Men Standing’: The Mag 7 Are Propping Up the S&P 500, Then Why Are Your ETFs at Risk? | Elon Musk Has a Warning for AI Data Center Investors, Says Funding Is Only Half the Battle: 'SpaceX Has a Super Cracked Team… Even We Find It Very Difficult'
AMD: Chip Stocks Slide as South Korea's KOSPI Plunges, J&J Sinks 6%: Stock Market Today | Fermi Secures AMD Backing For Texas AI Project | Credo Technology Group To Unveil Its OmniConnect Weaver Memory Fanout Gearbox On AMD Versal AI Edge Series Gen 2 Adaptive SoC Evaluation Board
PLTR: Dan Ives Says AI Stock Selloff ‘Opportunity to Own the Winners’: Here Are 7 Companies He Named | 10 Information Technology Stocks With Whale Alerts In Today’s Session | Ondas Wants to Run Pentagon AI with Palantir-Powered Regna AI
COIN: Citigroup Maintains Buy on Coinbase Global, Raises Price Target to $230 | EXCLUSIVE: Tether Co-Founder Names Coinbase, Circle and Robinhood as His Top Blockchain Stocks | Bitmine Immersion Technologies Reports $16.2B In Crypto + Total Cash & Marketable Securities + Moonshots Holdings; Crypto Holdings Comprise Of 6,028,946 ETH At $2,544 Per ETH As Of Oct. 11
MSFT: Wall Street’s ‘Last Men Standing’: The Mag 7 Are Propping Up the S&P 500, Then Why Are Your ETFs at Risk? | 'OpenAI CFO Says Firms Using Chinese AI Models Are Risking Safety' - Bloomberg Exclusive | AI Breaches Cost $6 Million: 3 Security Markets Investors Should Watch
JPM: RBC Capital Reiterates Outperform on JPMorgan Chase, Maintains $370 Price Target | JPMorgan Analysts Boost Their Forecasts After Q3 Results | Meta To Rally More Than 11%? Here Are 10 Top Analyst Forecasts For Wednesday
LLY: U.K. Medicines And Healthcare Products Regulatory Agency Authorizes Eli Lilly's Onswik For Adults With Type 2 Diabetes | Prelude Therapeutics Enters Clinical Trial Collaboration And Supply Agreement With Eli Lilly For Supply Of Its CDK4/6 Kinase Inhibitor, Abemaciclib And Its Oral Estrogen Receptor Antagonist Imlunestrant | RBC Capital Reiterates Outperform on Eli Lilly, Maintains $1500 Price Target
XOM: Guyana May Scale Back LNG Plans As Exxon Needs More Gas For Its Wells, Sources Say | Cyclicals Lead Sectors In Tuesday Trading As Health Care Trails | 9 Of 11 Sectors Rise Monday As Cyclicals Lead
COST: 9 Of 11 Sectors Rise Friday As Real Estate Leads | RBC Capital Reiterates Sector Perform on Costco Wholesale, Maintains $1000 Price Target | The $90 Social Security Payment Is a Tiny Stimulus. The Retiree Economy Is a Market Giant
CAT: What's Going On With Caterpillar Stock Wednesday? | Chip Stocks Slide as South Korea's KOSPI Plunges, J&J Sinks 6%: Stock Market Today | Cyclicals Lead Sectors In Tuesday Trading As Health Care Trails

## Scores
```json
{
  "TSLA": -0.1,
  "AMD": 0.2,
  "PLTR": 0.4,
  "COIN": 0.5,
  "MSFT": -0.2,
  "JPM": 0.4,
  "LLY": 0.6,
  "XOM": -0.2,
  "COST": 0.3,
  "CAT": -0.1
}
```
