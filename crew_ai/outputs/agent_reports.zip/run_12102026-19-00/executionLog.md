# Execution Log

- [1/6] BUY 22 MSFT @ limit 541.34 (RAMS 82.7, stop-loss 532.17) - RAMS 82.7 above buy level - OrderStatus.PENDING_NEW
- [2/6] BUY 12 COST @ limit 961.49 (RAMS 79.8, stop-loss 949.61) - RAMS 79.8 above buy level - OrderStatus.PENDING_NEW
- [3/6] BUY 72 PLTR @ limit 206.97 (RAMS 76.2, stop-loss 201.10) - RAMS 76.2 above buy level - OrderStatus.PENDING_NEW
- [4/6] BUY 35 JPM @ limit 335.56 (RAMS 76.0, stop-loss 331.43) - RAMS 76.0 above buy level - OrderStatus.PENDING_NEW
- [5/6] BUY 10 LLY @ limit 1186.20 (RAMS 75.7, stop-loss 1160.06) - RAMS 75.7 above buy level - OrderStatus.PENDING_NEW
- [6/6] BUY 69 XOM @ limit 172.33 (RAMS 73.4, stop-loss 169.51) - RAMS 73.4 above buy level - OrderStatus.PENDING_NEW
