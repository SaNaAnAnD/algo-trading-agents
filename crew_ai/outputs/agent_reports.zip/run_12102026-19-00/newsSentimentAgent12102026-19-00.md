# News Sentiment Agent

## Headlines
TSLA: China’s 4F² Threat To Micron—Houthis' Deadly Attack On Saudi Arabia Eclipses Trump’s Russian Diesel Deal | Tesla Faces New Luxury EV Rival in France as Lucid Plans 16 Locations | 9 Of 11 Sectors Rise Monday As Cyclicals Lead
AMD: Why Is Oracle Stock Falling on Monday? | Michael Burry's Big Short Gets Broader: Nvidia-Heavy Chip ETF, Nasdaq Now in Focus | AMD Makes Big Agentic AI Push With Helion
PLTR: Ondas Wants to Run Pentagon AI with Palantir-Powered Regna AI | Ondas Takes Its Palantir Partnership Deeper With New Sovereign AI Company | Quantum Computing Is Eyeing a 2028 Breakthrough, 2 ETFs Could Capture It
COIN: Bitmine Immersion Technologies Reports $16.2B In Crypto + Total Cash & Marketable Securities + Moonshots Holdings; Crypto Holdings Comprise Of 6,028,946 ETH At $2,544 Per ETH As Of Oct. 11 | Bitcoin, XRP Get the Spotlight—Could These 5 Altcoins Be Next? | EXCLUSIVE: Treasury Yields at 8%? This CEO Sees a Big Bitcoin ETF Opportunity
MSFT: 'Trump Administration Plans to Move AI Testing Agency Officials to White House; The White House Seeks To Integrate Caissi Into AI Decision-making Process' - The Information | China’s 4F² Threat To Micron—Houthis' Deadly Attack On Saudi Arabia Eclipses Trump’s Russian Diesel Deal | Why Is Oracle Stock Falling on Monday?
JPM: JPMorgan, Goldman Sachs Earnings Could Move This Dow ETF—Here’s the Portfolio Math | Nasdaq 100 Drops, SanDisk Tumbles 6% as AI Trade Falters: Stock Market Today | Dow Jones Industrial Average Gets Spotlight: 5 Earnings Reports Representing 25% of ETF’s Assets On Deck
LLY: RBC Capital Reiterates Outperform on Eli Lilly, Maintains $1500 Price Target | Stephen King Slams Trump’s New Press Secretary as Past Vaccine Conspiracy Theories, Third-Term Posts Spark Fresh Controversy: 'She Appears to Have Tried to…' | 10 Health Care Stocks Whale Activity In Today’s Session
XOM: 9 Of 11 Sectors Rise Monday As Cyclicals Lead | Iran Offers to Broker Saudi-Houthi Talks as Riyadh Vows an ‘Equally Serious’ Response to Deadly Airport Strikes: Report | Exxon Mobil Rejects Proposed $5.2 Billion Kashagan Fine Settlement: Report
COST: 9 Of 11 Sectors Rise Friday As Real Estate Leads | RBC Capital Reiterates Sector Perform on Costco Wholesale, Maintains $1000 Price Target | The $90 Social Security Payment Is a Tiny Stimulus. The Retiree Economy Is a Market Giant
CAT: 8 Industrials Stocks Whale Activity In Today’s Session | Stock Market Today: S&P 500, Dow Jones, Nasdaq 100 Futures Decline as Pentagon Prepares for Potential Military Strikes on Iran — APLD, LEVI, MU in Focus (UPDATED) | Applied Digital, Webull Corp., Super Micro Computer, Micron and Caterpillar: Why These 5 Stocks Are on Investors' Radars Today

## Scores
```json
{
  "TSLA": -0.2,
  "AMD": 0.4,
  "PLTR": 0.5,
  "COIN": 0.2,
  "MSFT": 0.0,
  "JPM": 0.1,
  "LLY": 0.5,
  "XOM": 0.2,
  "COST": 0.4,
  "CAT": 0.1
}
```
