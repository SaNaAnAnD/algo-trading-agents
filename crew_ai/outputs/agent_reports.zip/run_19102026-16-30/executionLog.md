# Execution Log

- MCP unavailable: Error calling tool 'compute_rams': HTTPSConnectionPool(host='paper-api.alpaca.markets', port=443): Read timed out. (read timeout=None)
