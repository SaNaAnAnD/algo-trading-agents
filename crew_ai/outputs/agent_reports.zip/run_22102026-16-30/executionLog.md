# Execution Log

- [1/3] BUY 8 LLY @ limit 1320.93 (RAMS 84.2, stop-loss 1288.72) - RAMS 84.2 strong and position in profit - OrderStatus.PENDING_NEW
- [2/3] BUY 10 COST @ limit 1014.60 (RAMS 83.8, stop-loss 1000.64) - RAMS 83.8 strong and position in profit - OrderStatus.PENDING_NEW
- [3/3] BUY 40 PLTR @ limit 199.76 (RAMS 77.2, stop-loss 192.88) - RAMS 77.2 above buy level - OrderStatus.PENDING_NEW
