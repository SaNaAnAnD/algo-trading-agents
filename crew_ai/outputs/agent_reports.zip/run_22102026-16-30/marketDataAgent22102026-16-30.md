# Market Data Agent

## 📊 Market Regime & Overview  
- **SPY Indicator:** **BEAR** – the broad U.S. market is in a down‑trend, favoring defensive positioning and careful risk management.  
- **Key Themes:**  
  - **Overbought Leaders:** COST and LLY show strong up‑trends but RSI > 70, hinting at short‑term pull‑backs.  
  - **Weak Momentum & Volume:** Many high‑profile names (AMD, CAT, COIN, MSFT, XOM, JPM) lack trend, momentum, or participation, making them poor candidates for new longs in this regime.  
  - **Breakout Signals:** Only LLY registers a perfect breakout score (100); COST’s breakout is moderate (66).  

## 💰 Account Snapshot (Paper‑Trading)  
| Metric | Amount |
|--------|--------|
| **Cash** | **$97,609.55** |
| **Buying Power** | **$397,921.87** |
| **Portfolio Value** | **$100,282.29** |
| **Equity** | **$100,282.29** |

### Open Positions (Unrealized P/L)  
| Symbol | Qty | Avg Entry | Current | Market Value | Unrealized P/L | % |
|--------|-----|-----------|---------|--------------|----------------|---|
| **AAPL** | 1 | $337.81 | $346.25 | $346.25 | **+$8.44** | **+2.5 %** |
| **COST** | 1 | $958.79 | $1,011.22 | $1,011.22 | **+$52.43** | **+5.5 %** |
| **LLY** | 1 | $1,210.99 | $1,315.30 | $1,315.30 | **+$104.31** | **+8.6 %** |

*Overall the paper portfolio is **+2.9 %** above cash, reflecting modest gains despite the bear backdrop.*

## 🔎 Analyst Highlights (RAMS & Pillar Scores)  

### Strongest Candidates  
- **COST** – RAMS **79.3** (Trend 100, Momentum 80, Volume 75, Breakout 66)  
  - *Warning:* RSI 76 → overbought; consider tight stops or partial profit‑taking.  
- **LLY** – RAMS **79.0** (Trend 100, Momentum 80, Volume 50, Breakout 100)  
  - *Warning:* RSI 71.3 → overbought; monitor for correction.

### Weakest Candidates  
| Symbol | RAMS | Key Deficiencies |
|--------|------|------------------|
| **AMD** | 14.6 | No trend, zero momentum, low volume, RSI 30 (oversold) |
| **CAT** | 18.3 | Flat trend, zero momentum, modest volume |
| **COIN** | 24.8 | No trend or breakout despite decent volume |
| **MSFT** | 25.8 | Weak trend, zero momentum, low RSI |
| **XOM** | 25.8 | Trend present but zero volume, no momentum |
| **JPM** | 32.7 | No trend, low volume, modest momentum |

### General Warnings  
- **RSI Overbought:** COST & LLY may face short‑term pull‑backs.  
- **Low Volume / Momentum:** JPM, XOM, AMD, etc., could exhibit erratic moves; avoid initiating new longs until scores improve.  
- **Breakout Landscape:** In a bear market, breakout opportunities are scarce—focus on the few high‑RAMS leaders with disciplined risk controls.

## 📌 Takeaway for the Desk  
- **Maintain current longs** (AAPL, COST, LLY) while tightening stops on the overbought leaders.  
- **Allocate new capital** cautiously: prioritize high‑RAMS, strong breakout signals (LLY) and stay out of weak‑score stocks until the regime shifts.  
- **Leverage buying power** for defensive or hedging instruments (e.g., inverse ETFs, protective puts) to protect against further downside.