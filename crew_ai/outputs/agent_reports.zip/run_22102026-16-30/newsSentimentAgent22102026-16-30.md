# News Sentiment Agent

## Headlines
TSLA: RBC Capital Reiterates Outperform on Tesla, Maintains $480 Price Target | 'Elon Musk Makes $1 Billion Investment In Ellison’s Skydance' - Semafor Exclusive | ‘If You’re Not in a Body Anymore, There’s Definitely Gonna Be Some Difference’ — Elon Musk Says We Could Upload Ourselves Into Humanoids to Live Forever
AMD: Ken Griffin Calls AI a Bubble After Citadel Bought the Dip | Why Is Advanced Micro Devices Stock Trending Wednesday? | Susquehanna Adjusts Price Target on Advanced Micro Devices to $620 From $550
PLTR: Palantir Makes Sovereignty Its Selling Point After Ukraine's Starlink Disruptions | Stagwell Expands Partnership With Palantir Over AI-Powered Marketing Services | Citi Maintains Buy Rating and Raises Price Target for Palantir
COIN: Ripple Sees a $100 Million Opportunity for Banks—What’s in It for XRP? | 'Long Coins, Short Stocks': Expert Bullish on Bitcoin, Cautious on XRP, Coinbase, Circle | Coinbase Global Unit Reaches EUR3.3 Million Settlement with Irish Central Bank
MSFT: Uber Brings ChatGPT Work To All Employees With OpenAI | Microsoft and Boehringer Ingelheim Announce Strategic AI Collaboration | Merck Collaborates with Microsoft, NVIDIA, and Dawn Health on Patient Support Programs
JPM: $100 Invested In JPMorgan Chase 15 Years Ago Would Be Worth This Much Today | JPMorgan Chase Upgrades CME Group Inc. to Buy | TerraPay Integrates with Kinexys by J.P. Morgan
LLY: Eli Lilly and Company Breaks Ground on $5B Integrated Manufacturing Site in Virginia | Defensives Lead Sectors In Thursday Trading As Growth Trails | Eli Lilly Starts Construction On $5B Production Site In Richmond, Virginia
XOM: Shell and ExxonMobil Joint Venture Infineum Explores $8 Billion Sale | Defensives Lead Sectors In Thursday Trading As Growth Trails | 'Shell And Exxon’s $8B UK Chemicals Unit Put Up For Sale' - Financial Times
COST: IQBAR Launches Indulgent Protein Bites at Costco | Costco to Invest 4.475 Billion TWD in New Tainan Store | Costain Group PLC Appoints Joh. Berenberg, Gossler & Co. KG as Joint Corporate Broker
CAT: Defensives Lead Sectors In Thursday Trading As Growth Trails | IronSight AI and Fast Iron Partner to Enhance Inventory Management for Caterpillar Dealers | 10 Industrials Stocks Whale Activity In Today’s Session

## Scores
```json
{
  "TSLA": 0.6,
  "AMD": 0.2,
  "PLTR": 0.7,
  "COIN": -0.2,
  "MSFT": 0.8,
  "JPM": 0.6,
  "LLY": 0.7,
  "XOM": -0.1,
  "COST": 0.6,
  "CAT": 0.5
}
```
