# Execution Log

- [1/2] SELL 1 LLY @ limit 1254.83 (RAMS 78.3, stop-loss 1227.34) - take half profit - OrderStatus.PENDING_NEW
- [2/2] SELL 1 XOM @ limit 175.33 (RAMS 55.1, stop-loss 173.15) - take half profit - OrderStatus.PENDING_NEW
