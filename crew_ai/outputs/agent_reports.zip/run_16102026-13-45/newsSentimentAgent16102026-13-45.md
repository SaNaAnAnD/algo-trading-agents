# News Sentiment Agent

## Headlines
TSLA: Space Stock Watch: SpaceX Spectrum Deal, Rocket Lab Delays, Tesla Merger Chatter | TSLA, MU, CRWV and More: 5 Stocks Investors Couldn't Stop Buzzing About This Week (CORRECTED) | Stock Market Today: Dow Jones, S&P 500 Futures Rise, Nasdaq Falls as Bessent Intensifies Economic Pressure on Iran— TSLA, AA, IBKR in Focus (UPDATED)
AMD: Taiwan Semiconductor Holds the Cards As NVIDIA, Apple and AMD Battle for Limited AI Chip Capacity | Rate Pressure vs. AI Demand: Rising Treasury Yields Trigger Nvidia, AMD Slump | AI Financing Fears Hammer Chip Stocks: These 2 ETFs Are Cashing In on the Sell-Off
PLTR: Trump’s $330 Million White House Ballroom Donor List Reveals Nvidia, Apple and Google Among Top Tech Contributors: Report | Cathie Wood Buys $13.4 Million of CoreWeave Stock as Jensen Huang Says ‘Strength Is Improving Every Day,’ Ark Trims Amazon and Palantir | Mizuho Maintains Outperform on Palantir Technologies, Raises Price Target to $245
COIN: Marqeta Collaborates With Coinbase To Bring Stablecoin-Backed Cards To Both Crypto-Native And Non-Crypto Firms | Coinbase Says Users May Face Delayed Sends On TON Network; Receives, Buys, Sells, Fiat Withdrawals And Deposits Not Affected, Funds Safe | 'Taiwan Blocks Coinbase, Kalshi Over Suspected Election Bets' - Bloomberg
MSFT: StoneX Maintains Buy on Microsoft, Raises Price Target to $600 | Trump’s $330 Million White House Ballroom Donor List Reveals Nvidia, Apple and Google Among Top Tech Contributors: Report | Reported October 15, 'DeepSeek offers user refunds after suffering another major outage' - SCMP
JPM: Trump’s $330 Million White House Ballroom Donor List Reveals Nvidia, Apple and Google Among Top Tech Contributors: Report | GameStop CEO Ryan Cohen Warns Humans Could Attack Smarter Robots — ‘Whether That Ends Up Being World War III, I Don’t Know’ | Jamie Dimon Warns AI Agents That Make Payments on Your Behalf ‘May Not’ Act Properly: AI Revolution Like a ‘Tsunami’ That Must Be Managed
LLY: Eli Lilly Receives EMA CHMP Positive Opinion Recommending Marketing Authorization For Foundayo For Treatment Of Type 2 Diabetes Mellitus And For Weight Management | Eli Lilly Says New Drug Drives Comprehensive Disease Control in Ulcerative Colitis Patients | Defensives Lead Sectors In Thursday Trading As Technology Trails
XOM: ExxonMobil Q3 Adjusting Items Include Estimated Timing Effects Of -$2.50B | ExxonMobil Announces Q3 Upstream Earnings Impact Of $300M From Change In Gas Prices; Liquids Price Changes To Impact Q3 Upstream Earnings By -$1.3B | ExxonMobil Announces Q3 Energy Products Earnings Impact Of $4.5B From Changes In Margins QoQ; Margins Changes To Impact Q3 Specialty Products Earnings By $500M; Will Chemical Products Earnings By -$600M
COST: Tigress Financial Maintains Buy on Costco Wholesale, Raises Price Target to $1250 | This House of Representative Just Sold Up To $65K In AutoZone Stock | Why Is Costco (COST) Stock Trending After Hours?
CAT: Caterpillar Investing $10M In Its North Carolina Operations | Oppenheimer Maintains Outperform on Caterpillar, Lowers Price Target to $1009 | Nasdaq 100 Drops 1% on Hot CPI, SOXX Falls 7th Day: Stock Market Today

## Scores
```json
{
  "TSLA": 0.2,
  "AMD": -0.3,
  "PLTR": 0.5,
  "COIN": -0.1,
  "MSFT": 0.4,
  "JPM": -0.2,
  "LLY": 0.7,
  "XOM": -0.2,
  "COST": 0.5,
  "CAT": -0.1
}
```
