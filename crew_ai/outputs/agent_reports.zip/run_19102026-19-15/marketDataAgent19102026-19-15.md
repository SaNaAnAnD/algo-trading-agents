# Market Data Agent

**Market Summary – Bear Regime (SPY)**  

---

### 📊 Macro & Sentiment Snapshot
- **Overall regime:** Bear (SPY indicates downside bias).  
- **Key sentiment cues:**  
  - Positive tilt for **AMD (+0.6), PLTR (+0.7), JPM (+0.3), LLY (+0.6), COST (+0.5)**.  
  - Negative sentiment for **TSLA (‑0.2), COIN (‑0.4), XOM (‑0.3), MSFT (‑0.1)**.  
- **Implication:** While the market leans lower, a few high‑quality names retain bullish sentiment; however, technical strength remains the primary filter in a bear environment.

---

### 💼 Account Overview (Paper‑Trading Desk)

| Metric | Value |
|--------|-------|
| **Cash** | **$85,808.17** |
| **Buying Power** | **$384,011.21** |
| **Portfolio Value / Equity** | **$100,371.93** |
| **Unrealized P/L** | **+$82.08** (≈ 0.08% gain) |

**Position Highlights**

| Symbol | Qty | Avg. Entry | Current | Δ % | Comment |
|--------|-----|------------|---------|-----|---------|
| **AAPL** | 1 | $337.81 | $343.13 | +1.6% | Small upside; tech still resilient. |
| **COST** | 1 | $958.79 | $996.24 | +3.9% | Strong consumer‑discretionary demand; hold. |
| **LLY** | 1 | $1,210.99 | $1,250.15 | +3.2% | Defensive health play; modest gain. |
| **XOM** | 67 | $178.52 | $178.72 | +0.1% | Near‑flat; technical buy‑threshold met. |

*Portfolio is modestly up, driven by defensive and consumer staples exposure.*

---

### 🔧 Technical Takeaways (RAMS ≥ 75 = Buy)

| Stock | RAMS | Trend | Momentum | Volume | Breakout | RSI | Signal |
|-------|------|-------|----------|--------|----------|-----|--------|
| **XOM** | **76.8** | 100 | 60 | 75 | 100 | 66.1 | **Hold / modest add** (only stock above buy threshold). |
| **COST** | 60.4 | 100 | 40 | 50 | 34 | 66.7 | **Watch** – solid trend, approaching overbought. |
| **MSFT** | 61.1 | 50 | 80 | 75 | 34 | 50.4 | **Wait** – momentum strong but trend neutral. |
| **TSLA** | 57.0 | 25 | 80 | 75 | 67 | 57.0 | **Wait** – breakout present, weak trend. |

**Weakest (RAMS ≤ 30) – avoid in bear market:** CAT, AMD, JPM, COIN (flat trend, low volume, no breakout).

**RSI Alert:** XOM (66.1) & COST (66.7) nearing 70; monitor for potential pull‑backs.

---

### 🎯 Actionable Outlook

1. **Core defensive tilt:** Keep **LLY** and **COST** as stable holders; they provide modest upside with defensive bias.  
2. **Energy exposure:** **XOM** is the only stock clearing the buy threshold; consider a small position increase if risk‑adjusted capital permits.  
3. **Tech & growth:** With the market in a bear phase and **MSFT**/**TSLA** lacking clear trend, stay on the sidelines or use tight stop‑losses.  
4. **Avoid** the weakest group (CAT, AMD, JPM, COIN) until trend, volume, or breakout signals improve.  

---

*Overall, the desk sits in a low‑risk, slightly positive position. In a bear market, prioritize defensive holdings, monitor XOM for a modest add, and stay out of low‑trend, low‑volume stocks.*