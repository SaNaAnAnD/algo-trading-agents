# News Sentiment Agent

## Headlines
TSLA: ‘CoreWeave Is the Canary in the Coal Mine’: Expert Warns More AI Debt Will Slide into Distress | 10 Consumer Discretionary Stocks With Whale Alerts In Today’s Session | Waymo Is Bringing Robotaxis to Canada in 2028 — Toronto’s Winter Weather Will Put Them to the Test
AMD: Why Is AMD Stock Surging on Monday? | Nasdaq 100 Stocks Add Nearly $500 Billion As Chips Battle To Snap 2008-Style Rout | Where Trump’s Portfolio Meets His Power: Nvidia, Palantir, Dell and More
PLTR: Why Is Palantir Technologies Stock Gaining Monday? | Where Trump’s Portfolio Meets His Power: Nvidia, Palantir, Dell and More | Knox Systems Announces New Partnership With Palantir Technologies To Accelerate Secure AI Deployment In FedRAMP And IL5 Environments
COIN: JPMorgan Taps Ethereum for JPM Coin as Tokenization Race Heats Up | Trump Gave Crypto What It Wanted: Is He Also Its Biggest Problem? | Coinbase Strikes Marqeta Deal but COIN Loses 3%
MSFT: Microsoft Walks Away From AI Data Center Deal, but SemiAnalysis Predicts 50-GW Boom in 2027 | Putin’s Proposed Trump-Xi Summit In China Could Hurt US Stocks Long Term; Meta And Tesla Earnings Ahead | 'Of Course' Bitcoin Could Grow to $50 Trillion, Jordi Visser Says: But How?
JPM: What's Going On With Exxon Stock On Monday? | JPMorgan Taps Ethereum for JPM Coin as Tokenization Race Heats Up | ServiceNow, Eaton, SentinelOne And A Financial Stock: CNBC’s ‘Final Trades’
LLY: Swiss Pharma Giant Roche Suspends German Capital Commitments Amid Dispute Over Drug Discounts | Eli Lilly’s Omvoh Shows 1-Year Phase 3 Results for Kids with Ulcerative Colitis | Reported Sunday, Lilly Brings Updated Phase 3 Selpercatinib Data Versus Cabozantinib Or Vandetanib In RET-Mutant Medullary Thyroid Cancer To ESMO 2026, Alongside Sofetabart Mipitecan, Olomorasib And Abemaciclib Presentations
XOM: What's Going On With Exxon Stock On Monday? | 9 Of 11 Sectors Fall As Growth Leads | Dow Jones, Nasdaq 100, S&P 500 Outlook: Top Catalysts to Move US Stocks This Week
COST: Tigress Financial Maintains Buy on Costco Wholesale, Raises Price Target to $1250 | This House of Representative Just Sold Up To $65K In AutoZone Stock | Why Is Costco (COST) Stock Trending After Hours?
CAT: Caterpillar Investing $10M In Its North Carolina Operations | Oppenheimer Maintains Outperform on Caterpillar, Lowers Price Target to $1009 | Nasdaq 100 Drops 1% on Hot CPI, SOXX Falls 7th Day: Stock Market Today

## Scores
```json
{
  "TSLA": -0.2,
  "AMD": 0.6,
  "PLTR": 0.7,
  "COIN": -0.4,
  "MSFT": -0.1,
  "JPM": 0.3,
  "LLY": 0.6,
  "XOM": -0.3,
  "COST": 0.5,
  "CAT": -0.1
}
```
