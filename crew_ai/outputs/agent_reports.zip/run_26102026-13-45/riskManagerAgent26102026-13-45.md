# Risk Manager Agent

## Proposed orders
1. BUY 65 XOM @ limit 183.65 (RAMS 88.7) - RAMS 88.7 above buy level

## Review
- **Order 1 – BUY 65 XOM @ limit 183.65** – **APPROVED** – Reason: The purchase fits within available buying power, adds a new Energy sector exposure (no current overlap), the news sentiment for XOM is modestly positive (0.3) and not a red flag, and there are no signs of extreme overbought conditions or concentration risk.