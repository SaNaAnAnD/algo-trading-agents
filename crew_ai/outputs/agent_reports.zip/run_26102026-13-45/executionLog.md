# Execution Log

- [1/1] BUY 65 XOM @ limit 183.65 (RAMS 88.7, stop-loss 180.01) - RAMS 88.7 above buy level - OrderStatus.PENDING_NEW
