# Execution Log

- [1/1] BUY 66 XOM @ limit 179.22 (RAMS 82.0, stop-loss 176.23) - RAMS 82.0 strong and position in profit - OrderStatus.PENDING_NEW
