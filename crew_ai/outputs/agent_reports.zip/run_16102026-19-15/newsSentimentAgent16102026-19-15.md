# News Sentiment Agent

## Headlines
TSLA: Tesla's Flying Roadster Sends Delivery Odds Tumbling Despite Spectacular Demo | Tesla's Roadster Just Made SpaceX More Valuable. Does Tesla Get Any Credit? | Why Is Applied Digital Stock Falling Friday?
AMD: SemiAnalysis Pots On X "SHOCKING: We have confirmed that multiple Neoclouds have been refused access to GTC Berlin due to them adding AMD GPUs, TPUs, and other chips to their cloud offerings. Note that this doesn't apply to hyperscalers, as they have more buying power. But for neoclouds, executives feel NVIDIA has been using high-pressure tactics to keep them NVIDIA-only...." | What's Going On With Fermi Stock Friday? | Taiwan Semiconductor Holds the Cards As NVIDIA, Apple and AMD Battle for Limited AI Chip Capacity
PLTR: Palantir Technologies Stock Is Falling Friday: What's Going On? | Trump’s $330 Million White House Ballroom Donor List Reveals Nvidia, Apple and Google Among Top Tech Contributors: Report (UPDATED) | Cathie Wood Buys $13.4 Million of CoreWeave Stock as Jensen Huang Says ‘Strength Is Improving Every Day,’ Ark Trims Amazon and Palantir
COIN: Coinbase Strikes Marqeta Deal but COIN Loses 3% | Looking Beyond Bitcoin? Analysts See Bigger Opportunities in These 5 Altcoins | Marqeta Collaborates With Coinbase To Bring Stablecoin-Backed Cards To Both Crypto-Native And Non-Crypto Firms
MSFT: 10 Information Technology Stocks Whale Activity In Today’s Session | 9 Of 11 Sectors Rise In Friday Trading As Cyclicals Lead | Rep. David Taylor Has Bought Up to $45K Worth Of AT&T Stock: Here’s What You Should Know
JPM: CNBC Halftime Report Final Trades: ServiceNow, Eaton, SentinelOne, JP Morgan Chase | 9 Of 11 Sectors Rise In Friday Trading As Cyclicals Lead | Trump’s $330 Million White House Ballroom Donor List Reveals Nvidia, Apple and Google Among Top Tech Contributors: Report (UPDATED)
LLY: Eli Lilly's GLP-1 Pill Wins Key European Backing for Obesity and Diabetes | 9 Of 11 Sectors Rise In Friday Trading As Cyclicals Lead | Eli Lilly Receives EMA CHMP Positive Opinion Recommending Marketing Authorization For Foundayo For Treatment Of Type 2 Diabetes Mellitus And For Weight Management
XOM: ExxonMobil Sees $4.5 Billion Boost from Higher Refining Margins | Here’s How Much You Would Have Made Owning ExxonMobil Holdings Stock In The Last 5 Years | ExxonMobil Q3 Adjusting Items Include Estimated Timing Effects Of -$2.50B
COST: Tigress Financial Maintains Buy on Costco Wholesale, Raises Price Target to $1250 | This House of Representative Just Sold Up To $65K In AutoZone Stock | Why Is Costco (COST) Stock Trending After Hours?
CAT: Caterpillar Investing $10M In Its North Carolina Operations | Oppenheimer Maintains Outperform on Caterpillar, Lowers Price Target to $1009 | Nasdaq 100 Drops 1% on Hot CPI, SOXX Falls 7th Day: Stock Market Today

## Scores
```json
{
  "TSLA": -0.3,
  "AMD": 0.2,
  "PLTR": -0.5,
  "COIN": -0.2,
  "MSFT": 0.0,
  "JPM": 0.0,
  "LLY": 0.7,
  "XOM": 0.4,
  "COST": 0.5,
  "CAT": 0.2
}
```
