# Risk Manager Agent

## Proposed orders
1. BUY 66 XOM @ limit 179.22 (RAMS 82.0) - RAMS 82.0 strong and position in profit

## Review
- **APPROVED** – Adding 66 XOM shares raises energy exposure to ~12 % of the portfolio, which is within acceptable concentration limits. The news sentiment for XOM is positive (0.4) and the RAMS score is strong (82). In a bear regime the trade is still justified by the strong signal and modest sector weight.