# Technical Analyst Agent

| Symbol | RAMS | Trend | Momentum | Volume | Breakout | RSI | Signal |
|---|---|---|---|---|---|---|---|
| TSLA | 79.0 | 100 | 80 | 50 | 100 | 64.8 | BUY |
| XOM | 76.8 | 100 | 60 | 75 | 100 | 70.5 | HOLD |
| MSFT | 67.8 | 50 | 80 | 75 | 100 | 60.5 | WAIT |
| PLTR | 64.9 | 75 | 80 | 50 | 34 | 56.8 | WAIT |
| AMD | 57.0 | 25 | 80 | 75 | 67 | 55.6 | WAIT |
| LLY | 39.7 | 50 | 20 | 75 | 0 | 49.3 | SELL |
| CAT | 36.7 | 0 | 60 | 75 | 0 | 41.9 | WAIT |
| JPM | 36.4 | 25 | 60 | 0 | 34 | 52.3 | WAIT |
| COST | 33.8 | 75 | 0 | 25 | 0 | 45.3 | SELL |
| COIN | 7.5 | 0 | 0 | 0 | 0 | 35.5 | WAIT |

**Technical Snapshot – Bear Market (Buy threshold = 75)**  

**💪 Strongest Candidates**  
- **TSLA (RAMS 79.0)** – Highest overall score; perfect Trend (100) and Breakout (100); Momentum solid (80). RSI 64.8 is safe.  
- **XOM (RAMS 76.8)** – Strong Trend (100) and Breakout (100); decent Momentum (60) and Volume (75). RSI 70.5 is just above the typical 70‑level – watch for over‑extension.  
- **MSFT (RAMS 67.8)** – Good Momentum (80) and Breakout (100); Trend moderate (50). RSI 60.5 comfortable.

**📉 Weakest Candidates**  
- **COIN (RAMS 7.5)** – Zero scores across all pillars; RSI 35.5 indicates deep oversold but no supporting strength.  
- **COST (RAMS 33.8)** – Low Momentum (0) and Breakout (0); weak Volume (25) and RSI 45.3.  
- **LLY (RAMS 39.7)** – Low Momentum (20) and Breakout (0); RSI 49.3 neutral but overall weakness.

**⚠️ Warnings & Red Flags**  
- **RSI > 70**: XOM (70.5) – potential overbought in a bear regime; consider tightening stops.  
- **Weak Volume Pillar (< 50)**: TSLA (50) and PLTR (50) – volume support is only moderate; price moves may be less reliable.  
- **Breakout Scores Near Zero**: LLY (0), CAT (0), JPM (34), COST (0), COIN (0) – limited breakout potential; avoid aggressive entries.  
- **Trend Scores at 0**: CAT (0) and COIN (0) – no directional bias; likely to stay flat or decline.  

**Takeaway**: In the current bear market, TSLA and XOM are the only stocks crossing the buy‑threshold and showing robust trend/breakout characteristics, though XOM’s RSI warrants caution. The remaining symbols either lack sufficient momentum, volume, or breakout strength, making them unsuitable for new long positions at this time.