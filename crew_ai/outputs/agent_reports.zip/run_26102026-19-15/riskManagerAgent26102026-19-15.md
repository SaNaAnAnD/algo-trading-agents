# Risk Manager Agent

## Proposed orders
1. SELL 9 LLY @ limit 1274.28 (RAMS 45.0) - stop-loss hit
2. SELL 11 COST @ limit 997.22 (RAMS 33.8) - RAMS 33.8 below sell level
3. BUY 20 TSLA @ limit 396.10 (RAMS 78.2) - RAMS 78.2 above buy level

## Review
- **Order 1 – SELL 9 LLY @ limit 1274.28** – **APPROVED** – Reduces exposure to a losing healthcare position; aligns with the bear regime and the stop‑loss trigger.  
- **Order 2 – SELL 11 COST @ limit 997.22** – **APPROVED** – Cuts a modestly under‑performing consumer‑staples holding; no adverse news and helps limit downside risk.  
- **Order 3 – BUY 20 TSLA @ limit 396.10** – **REJECTED** – Adding a high‑volatility tech/auto stock in a bear market with negative news (TSLA score –0.1) and a high RAMS reading increases sector concentration and overbought risk.