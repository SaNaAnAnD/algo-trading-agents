# Market Data Agent

```markdown
# 📊 Market Summary (Bear Regime)

**Overall Market Tone:**  
- **SPY indicates a BEAR market** – risk‑off sentiment dominates, defensive positioning is favored.

---

## 💰 Account Snapshot
| Metric            | Value (USD) |
|-------------------|------------|
| **Cash**          | $64,935.07 |
| **Buying Power**  | $357,331.79 |
| **Portfolio Value** | $99,789.18 |
| **Equity**        | $99,789.18 |

### Open Positions & P&L
| Symbol | Qty | Avg Entry | Current | Market Value | Unrealized P/L | % P/L |
|--------|-----|-----------|---------|--------------|----------------|-------|
| **AAPL** | 1   | $337.81   | $343.45 | $343.45      | **+$5.64**     | **+1.67%** |
| **COST** | 11  | $1,006.76 | $1,000.32 | $11,003.52 | **‑$70.87**   | **‑0.64%** |
| **LLY**  | 9   | $1,304.62 | $1,279.26 | $11,513.34 | **‑$228.21**  | **‑1.94%** |
| **XOM**  | 65  | $183.10   | $184.50 | $11,992.50 | **+$91.00**   | **+0.77%** |

*The portfolio is modestly positive (+$5.64 + $91 – $70.87 – $228.21 ≈ **‑$202.44** overall), reflecting the bear backdrop.*

---

## 🔎 Analyst & Technical Highlights (Buy Threshold = 75)

### Strongest Candidates (RAMS ≥ 75)
| Symbol | RAMS | Trend | Breakout | Momentum | Volume | RSI |
|--------|------|-------|----------|----------|--------|-----|
| **TSLA** | **79.0** | 100 | 100 | 80 | 50 | 64.8 |
| **XOM**  | **76.8** | 100 | 100 | 60 | 75 | **70.5** (watch) |
| **MSFT** | 67.8 | 50 | 100 | 80 | — | 60.5 |

*Only TSLA and XOM clear the 75‑point buy threshold, with solid trend & breakout scores. MSFT is close but falls short on the overall score.*

### Weakest Candidates (RAMS < 40)
| Symbol | RAMS | Key Deficiencies |
|--------|------|------------------|
| **COIN** | 7.5  | Zero scores across pillars; RSI 35.5 (deep oversold) |
| **COST** | 33.8 | No momentum or breakout; weak volume (25), RSI 45.3 |
| **LLY**  | 39.7 | Low momentum (20), no breakout, RSI 49.3 |

*These stocks lack the momentum, volume, or breakout strength needed for new long entries in a bear market.*

### Red‑Flag Alerts
- **RSI > 70:** XOM (70.5) – potential overbought; tighten stops.  
- **Weak Volume (< 50):** TSLA (50) & PLTR (50) – price moves may be less reliable.  
- **Breakout ≈ 0:** LLY, CAT, JPM, COST, COIN – limited breakout potential; avoid aggressive longs.  
- **Trend = 0:** CAT, COIN – no directional bias, likely flat/declining.

---

## 📈 Takeaway & Actionable Guidance
1. **Maintain defensive posture.** The bear regime suggests limiting new long exposure.  
2. **Consider scaling into TSLA** if you seek a high‑conviction trade, but watch volume and set disciplined stops.  
3. **XOM offers a strong trend but is near overbought;** treat as a short‑term play with tight risk controls.  
4. **Avoid adding to COST, LLY, COIN** until momentum or breakout signals improve.  
5. **Monitor cash & buying power** – ample liquidity remains for opportunistic entries if the market regime shifts.

*Overall, the portfolio is modestly positioned with a slight net loss, reflecting the broader bearish environment. Focus on high‑score, well‑supported stocks (TSLA, XOM) while staying vigilant on risk metrics.*