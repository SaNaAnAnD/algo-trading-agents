# Execution Log

- [1/2] SELL 9 LLY @ limit 1274.28 (RAMS 45.0, stop-loss 1253.59) - stop-loss hit - OrderStatus.PENDING_NEW
- [2/2] SELL 11 COST @ limit 997.22 (RAMS 33.8, stop-loss 990.04) - RAMS 33.8 below sell level - OrderStatus.PENDING_NEW
