# News Sentiment Agent

## Headlines
TSLA: Will Tesla's Roadster Fly Tonight? Prediction Markets Say It's Likely | 'Tesla Readies Flying Car Demo To Pump Up Sluggish Auto Business; Planning To Unveil Its Long-Promised New Roadster Sports Car Thursday In Texas, Reviving And Refreshing A Model That Tesla Stopped Producing More Than A Decade Ago' - Bloomberg News | GLJ Research Reiterates Sell on Tesla, Maintains $24.86 Price Target
AMD: AI Financing Fears Hammer Chip Stocks: These 2 ETFs Are Cashing In on the Sell-Off | Why Is AMD Stock Falling on Wednesday? | ASML Says AI Boom Is Boosting Pricing Power as Chipmakers Agree to Pay More
PLTR: Surf Air Mobility Expands Palantir-Powered AI Push With Fifth Aviation Software Deal | Customers Bancorp Announces Collaboration With Palantir To Deploy AI Software For Deposit Account Opening; Terms Not Disclosed | Surf Air Mobility Signs Definitive Agreement With Flying Zebra For OperatorOS, Surf Air Mobility's SurfOS Flight Operations Software For Part 135 Operators Powered By Palantir
COIN: 'Taiwan Blocks Coinbase, Kalshi Over Suspected Election Bets' - Bloomberg | Coinbase Investigates Possible NEAR Network Send And Receive Delays For Some Users, Says Funds Safe; Buys, Sells, Fiat Withdrawals And Deposits Unaffected | DriveWealth to Integrate Ripple as Evernorth Deploys XRP Treasury
MSFT: FTC Spokesman Says President Trump Task Force On AI To Meet Thursday | TD Cowen Maintains Buy on Microsoft, Raises Price Target to $625 | Politico Reported Microsoft President Warned White House Against Crackdown On Skilled Immigration
JPM: 'JPMorgan Mulls Revival of Software Debt Deal Lenders Had Shunned' - Bloomberg Exclusive | JPMorgan, Bank of America, Wells Fargo Among 9 Banks Accused of Political, Religious Debanking by OCC | Potential $100 Billion Anthropic IPO Could Boost Wall Street Banks: Which ETFs Stand to Benefit?
LLY: Eli Lilly Says New Drug Drives Comprehensive Disease Control in Ulcerative Colitis Patients | Defensives Lead Sectors In Thursday Trading As Technology Trails | Here’s How Much You Would Have Made Owning Eli Lilly Stock In The Last 20 Years
XOM: Defensives Lead Sectors In Thursday Trading As Technology Trails | 8 Of 11 Sectors Fall Wednesday As Defensives Lead | Guyana May Scale Back LNG Plans As Exxon Needs More Gas For Its Wells, Sources Say
COST: This House of Representative Just Sold Up To $65K In AutoZone Stock | Why Is Costco (COST) Stock Trending After Hours? | 8 Of 11 Sectors Fall Wednesday As Defensives Lead
CAT: Caterpillar Investing $10M In Its North Carolina Operations | Oppenheimer Maintains Outperform on Caterpillar, Lowers Price Target to $1009 | Nasdaq 100 Drops 1% on Hot CPI, SOXX Falls 7th Day: Stock Market Today

## Scores
```json
{
  "TSLA": 0.2,
  "AMD": -0.3,
  "PLTR": 0.5,
  "COIN": -0.6,
  "MSFT": 0.4,
  "JPM": 0.1,
  "LLY": 0.6,
  "XOM": -0.2,
  "COST": 0.0,
  "CAT": 0.2
}
```
