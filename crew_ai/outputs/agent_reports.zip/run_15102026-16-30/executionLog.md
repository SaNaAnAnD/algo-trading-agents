# Execution Log

- [1/3] SELL 1 COST @ limit 986.58 (RAMS 77.2, stop-loss 973.11) - take half profit - OrderStatus.PENDING_NEW
- [2/3] SELL 4 LLY @ limit 1268.42 (RAMS 91.0, stop-loss 1241.43) - take half profit - OrderStatus.PENDING_NEW
- [3/3] SELL 2 XOM @ limit 174.56 (RAMS 62.6, stop-loss 172.49) - take half profit - OrderStatus.PENDING_NEW
