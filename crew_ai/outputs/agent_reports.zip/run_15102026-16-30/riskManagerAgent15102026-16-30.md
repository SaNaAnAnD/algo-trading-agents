# Risk Manager Agent

## Proposed orders
1. SELL 1 COST @ limit 986.58 (RAMS 77.2) - take half profit
2. SELL 4 LLY @ limit 1268.42 (RAMS 91.0) - take half profit
3. SELL 2 XOM @ limit 174.56 (RAMS 62.6) - take half profit

## Review
- **Order 1 – SELL 1 COST @ limit 986.58** – **APPROVED** – Reduces a small consumer‑staples position, aligns with the bear regime, and the news score is neutral; no sector‑concentration or overbought concerns.

- **Order 2 – SELL 4 LLY @ limit 1268.42** – **APPROVED** – Takes partial profit on a relatively large healthcare holding, keeping sector exposure well‑under limits; despite a positive news score, profit‑taking is prudent in a bear market.

- **Order 3 – SELL 2 XOM @ limit 174.56** – **APPROVED** – Cuts exposure to energy amid slightly negative news, consistent with the bear regime and without creating sector concentration issues.