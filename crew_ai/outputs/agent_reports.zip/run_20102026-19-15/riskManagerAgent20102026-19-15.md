# Risk Manager Agent

## Proposed orders
1. BUY 21 TSLA @ limit 376.53 (RAMS 76.0) - RAMS 76.0 above buy level

## Review
- **REJECTED** – TSLA is currently overbought (RAMS 76 > buy level) and the portfolio is in a BEAR regime; adding a new, sizable position in an already high‑valuation, momentum‑driven stock would increase sector concentration and risk.