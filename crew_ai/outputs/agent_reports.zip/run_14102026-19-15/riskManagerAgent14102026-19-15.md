# Risk Manager Agent

## Proposed orders
1. SELL 3 COST @ limit 972.63 (RAMS 79.0) - take half profit
2. SELL 9 XOM @ limit 176.62 (RAMS 67.8) - take half profit

## Review
- **Order 1 – SELL 3 COST @ limit 972.63** – **APPROVED** – Reason: Taking half‑position profit trims exposure while keeping a modest stake in a sector (consumer staples) that currently has positive news; the sell does not create sector concentration issues in a bear regime.

- **Order 2 – SELL 9 XOM @ limit 176.62** – **APPROVED** – Reason: Energy stocks are under negative news pressure (XOM news score ‑0.25) and the market is in a bear regime; reducing the XOM position cuts downside risk without over‑exposing the portfolio to any single sector.