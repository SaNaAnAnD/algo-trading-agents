# News Sentiment Agent

## Headlines
TSLA: Elon Musk Backs Micron As MU Stock Falls 25%: Is This Memory ETF an AI Stock Bargain? | 10 Consumer Discretionary Stocks Whale Activity In Today’s Session | ASML Earnings Signal Strong AI Demand Yet Stock Falls, Emphasizing Market Character Shift—CPI Squashes Hopium
AMD: Why Is AMD Stock Falling on Wednesday? | ASML Says AI Boom Is Boosting Pricing Power as Chipmakers Agree to Pay More | Nasdaq 100 Drops 1% on Hot CPI, SOXX Falls 7th Day: Stock Market Today
PLTR: Palantir, Mayor Of London Reach Settlement Over Alleged Allegations Regarding Palantir's Unified Operational Analytics Contract With Metropolitan Police Service | Dan Ives Says AI Stock Selloff ‘Opportunity to Own the Winners’: Here Are 7 Companies He Named | 10 Information Technology Stocks With Whale Alerts In Today’s Session
COIN: DriveWealth to Integrate Ripple as Evernorth Deploys XRP Treasury | Banks Are Putting Deposits On Blockchain As Stablecoins Face A New Rival | Citigroup Maintains Buy on Coinbase Global, Raises Price Target to $230
MSFT: 'Eight U.S. States Sue OpenAI, Claiming ChatGPT Harms Children' - Reuters News | ASML Earnings Signal Strong AI Demand Yet Stock Falls, Emphasizing Market Character Shift—CPI Squashes Hopium | 'OpenAI Names Uday Ruddarraju to Lead Data Center, Computing Unit' - Bloomberg
JPM: JPMorgan Addresses 'Rogue Agents' as AI Gives Banks New Security Problems | Truist Securities Maintains Hold on JPMorgan Chase, Raises Price Target to $361 | Big Bank Succession Talk Heats Up as CEOs Stay Firmly in Charge
LLY: Nasdaq 100 Drops 1% on Hot CPI, SOXX Falls 7th Day: Stock Market Today | 8 Of 11 Sectors Fall Wednesday As Defensives Lead | Watching Eli Lilly; Hearing Investor Business Daily SwingTrader Buys Stock
XOM: 8 Of 11 Sectors Fall Wednesday As Defensives Lead | Guyana May Scale Back LNG Plans As Exxon Needs More Gas For Its Wells, Sources Say | Cyclicals Lead Sectors In Tuesday Trading As Health Care Trails
COST: 8 Of 11 Sectors Fall Wednesday As Defensives Lead | 9 Of 11 Sectors Rise Friday As Real Estate Leads | RBC Capital Reiterates Sector Perform on Costco Wholesale, Maintains $1000 Price Target
CAT: Oppenheimer Maintains Outperform on Caterpillar, Lowers Price Target to $1009 | Nasdaq 100 Drops 1% on Hot CPI, SOXX Falls 7th Day: Stock Market Today | What's Going On With Caterpillar Stock Wednesday?

## Scores
```json
{
  "TSLA": 0.1,
  "AMD": -0.2,
  "PLTR": 0.05,
  "COIN": 0.3,
  "MSFT": -0.15,
  "JPM": 0.1,
  "LLY": 0.15,
  "XOM": -0.25,
  "COST": 0.3,
  "CAT": -0.1
}
```
