# Execution Log

- [1/2] SELL 3 COST @ limit 972.63 (RAMS 79.0, stop-loss 965.03) - take half profit - OrderStatus.PENDING_NEW
- [2/2] SELL 9 XOM @ limit 176.62 (RAMS 67.8, stop-loss 174.97) - take half profit - OrderStatus.PENDING_NEW
