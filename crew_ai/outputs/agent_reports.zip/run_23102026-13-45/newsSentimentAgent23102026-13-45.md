# News Sentiment Agent

## Headlines
TSLA: Tesla Cancels Cybertruck Production Plans for Australia and New Zealand | Tesla Needs 20,000 Robots to 'Self-Play' in Order to Improve: Musk | Gary Black Says Tesla Investors Are Taking Elon Musk's Earnings Call Projections as 'Gospel' Despite Stock's 'Extreme Valuation Metrics'
AMD: Nvidia’s China Market Has Effectively Vanished: ‘Every Restriction Also Gives Chinese Suppliers a Larger Captive Market,’ Says Shay Boloor | Nasdaq Records Worst Session Since June: Investor Sentiment Weakens, Greed Index Moves To ‘Extreme Fear’ Zone | SOAR AI, Inc. Announces Contracted GPU Deployments Featuring AMD Instinct™ Accelerators
PLTR: Michael Burry Shares Chilling Song on AI: 'Watching Trillion-Dollar Monuments Become Obsolete' | Citigroup Maintains Buy on Palantir Technologies, Raises Price Target to $250 | Stagwell Expands Strategic AI Partnership with Palantir
COIN: Autonomous Research Adjusts Price Target on Coinbase Global | Bitcoin to $1 Million? Don't Expect 100X Returns Anymore, Dan Tapiero Says | Ripple Sees a $100 Million Opportunity for Banks—What’s in It for XRP?
MSFT: Microsoft Researchers Develop AI Tool for Sequential Medical Diagnosis | Anthropic’s Path to $1.5 Trillion Demands 30% Margins: Plausible, but Delivering Is Another Matter | OpenAI Signs Agreement With Poland’s NASK To Explore Collaboration On AI Safety, Security And Technical Research, Strengthening Safeguards Against Emerging Risks
JPM: JPMorgan Chase Files TR-1 Notification for Bodycote Plc | JPMorgan Chase Reports Change in Major Holding of Intertek Group PLC | JPMorgan Chase Presents Quantum Computing Research at IEEE Conference
LLY: More Americans Now Take GLP-1 Drugs for Weight Loss Than Diabetes as Food, Alcohol and Apparel Habits Shift, Survey Finds | Eli Lilly and Company Breaks Ground on $5B Integrated Manufacturing Site in Virginia | Defensives Lead Sectors In Thursday Trading As Growth Trails
XOM: ExxonMobil Joliet Refinery Experiences Operational Disruption | 'Qatar Scours for More LNG to Boost Supply Outside Middle East' - Bloomberg Exclusive | Shell and ExxonMobil Joint Venture Infineum Explores $8 Billion Sale
COST: Urban Remedy Launches Chocolate Protein Collagen Shake at Select Costco Warehouses | Walmart’s Best Month Since 1999 Leads a Record Staples Rally: Is This a Warning Sign? | IQBAR Launches Indulgent Protein Bites at Costco
CAT: GE Vernova Stock Rebounds, AI Sell-Off Gives Way To Earnings Focus | AI Sell-Off Spreads to Industrials: Caterpillar, GE Vernova, Vertiv Trapped in Bear Market | Michael Burry Shares Chilling Song on AI: 'Watching Trillion-Dollar Monuments Become Obsolete'

## Scores
```json
{
  "TSLA": -0.5,
  "AMD": -0.2,
  "PLTR": 0.4,
  "COIN": -0.3,
  "MSFT": 0.5,
  "JPM": 0.1,
  "LLY": 0.6,
  "XOM": -0.2,
  "COST": 0.0,
  "CAT": -0.4
}
```
