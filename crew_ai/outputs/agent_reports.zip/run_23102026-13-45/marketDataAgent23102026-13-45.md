# Market Data Agent

## 📊 Market Summary (Bear Regime)

**Overall Market Tone**  
- SPY signals a **bear** regime, keeping the buy‑threshold at 75.  
- Tech and growth names (TSLA, AMD, COIN, MSFT) show **weak momentum** and low volume, reinforcing downside pressure.  
- Defensive and commodity‑linked stocks (COST, XOM) are the only ones near or above the buy threshold, but **COST** is edging into overbought territory.

**Account Snapshot**  
| Metric | Value |
|--------|-------|
| **Cash** | $76,836.57 |
| **Buying Power** | $371,976.29 |
| **Portfolio Value / Equity** | $99,918.72 |
| **Open Positions** | AAPL (↑1.1%), COST (↑0.6%), LLY (↓1.3%) |
| **Unrealized P/L** | +$11.29 (AAPL) +$65.31 (COST) –$148.20 (LLY) = **–$71.60 total** |

**Position Highlights**  
- **AAPL**: Small long (1 share) with modest gain; still a low‑risk exposure.  
- **COST**: Largest holding, modest upside (+0.6%) but RSI 70.9 signals a possible short‑term pull‑back.  
- **LLY**: Slight loss (‑1.3%); despite a decent RAMS score, low volume and zero breakout score make it vulnerable.

**Analyst Pillar Scores & Signals**  
| Symbol | RAMS | Trend | Momentum | Volume | Breakout | RSI | Signal |
|--------|------|-------|----------|--------|----------|-----|--------|
| **COST** | 73.5 | 100 | 60 | 75 | 67 | 70.9 | **HOLD** (watch overbought) |
| **XOM** | 67.9 | 75 | 100 | 75 | 66 | 67.1 | **WAIT** (await confirmation) |
| **LLY** | 57.7 | 75 | 80 | 25 | 0 | 52.0 | **HOLD** (volume weakness) |
| **AMD** | 14.6 | 0 | 0 | 25 | 33 | 36.1 | **AVOID** |
| **CAT** | 14.6 | 0 | 0 | 25 | 33 | 36.1 | **AVOID** |
| **PLTR** | 22.5 | 25 | 0 | 50 | 0 | 37.2 | **AVOID** |
| **JPM** | 18.7 | 0 | 0 | 75 | 0 | 41.7 | **AVOID** |

**Key Warnings**  
- **COST RSI 70.9** → near overbought; consider tightening stops or trimming if price stalls.  
- **LLY low volume (25)** → trend may not sustain without more participation.  
- **Zero breakout scores** for LLY, PLTR, JPM indicate lack of catalytic moves.  
- **Momentum deficiency** across most tech/crypto names (TSLA, MSFT, COIN, AMD, CAT) suggests further downside risk in a bear market.

**Actionable Takeaways**  
1. **Maintain** current COST exposure but monitor RSI; be ready to reduce if a pull‑back materialises.  
2. **Hold** XOM as a wait‑and‑see play; consider adding only after a clear breakout confirmation.  
3. **Re‑evaluate** LLY – consider scaling down unless volume improves.  
4. **Avoid** adding to weak stocks (AMD, CAT, PLTR, JPM) until the regime shifts.  
5. Preserve cash and buying power for opportunistic entries if any sector shows a breakout from the bear trend.