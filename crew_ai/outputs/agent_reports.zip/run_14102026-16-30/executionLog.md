# Execution Log

- [1/4] SELL 22 MSFT @ limit 534.49 (RAMS 26.2, stop-loss 527.89) - RAMS 26.2 below sell level - OrderStatus.PENDING_NEW
- [2/4] SELL 72 PLTR @ limit 202.59 (RAMS 39.8, stop-loss 197.14) - RAMS 39.8 below sell level - OrderStatus.PENDING_NEW
- [3/4] SELL 6 COST @ limit 973.57 (RAMS 77.8, stop-loss 965.77) - take half profit - OrderStatus.PENDING_NEW
- [4/4] SELL 17 XOM @ limit 176.30 (RAMS 82.0, stop-loss 174.45) - take half profit - OrderStatus.PENDING_NEW
