# News Sentiment Agent

## Headlines
TSLA: Nasdaq 100 Drops 1% on Hot CPI, SOXX Falls 7th Day: Stock Market Today | Bitcoin, Nvidia And Tesla ETFs Lead Wall Street’s Most Traded Funds | How To Trade SPY, QQQ, AAPL, MSFT, NVDA, GOOGL, META, And TSLA
AMD: Nasdaq 100 Drops 1% on Hot CPI, SOXX Falls 7th Day: Stock Market Today | AMD Challenges Nvidia's AI Inference Lead, SemiAnalysis Finds | Chip Stocks Slide as South Korea's KOSPI Plunges, J&J Sinks 6%: Stock Market Today
PLTR: Palantir, Mayor Of London Reach Settlement Over Alleged Allegations Regarding Palantir's Unified Operational Analytics Contract With Metropolitan Police Service | Dan Ives Says AI Stock Selloff ‘Opportunity to Own the Winners’: Here Are 7 Companies He Named | 10 Information Technology Stocks With Whale Alerts In Today’s Session
COIN: DriveWealth to Integrate Ripple as Evernorth Deploys XRP Treasury | Banks Are Putting Deposits On Blockchain As Stablecoins Face A New Rival | Citigroup Maintains Buy on Coinbase Global, Raises Price Target to $230
MSFT: 'OpenAI Names Uday Ruddarraju to Lead Data Center, Computing Unit' - Bloomberg | Apple Has Found No Evidence To Support OpenAI's Allegations; Says Apple Has Searched For The One File That OpenAI Has Identified, But Has Not Found It On Any Apple System; Co Has Strict Policies & Procedures In Place To Help Ensure That New Employees Don't Use Any Confidential Information From Prior Employer; Says OpenAI Has Failed To Respond To Apple’s Request For More Information That Would Aid In Its Investigation | OpenAI Brief In Apple Vs OpenAI Lawsuit Say Files Leaked Include Detailed Unreleased Device Images, Engineering Data, Supplier Info; Says Apple Has Not Assured It Is Not In Possession Of & Has Not Used OpenAI Confidential Data; Files Leaked By Employee Also Include Manufacturing Data About Devices
JPM: Big Bank Succession Talk Heats Up as CEOs Stay Firmly in Charge | Banks Are Putting Deposits On Blockchain As Stablecoins Face A New Rival | JPMorgan Chase Q2 Results Were ‘Best-In-Class,’ Analyst Highlights CIB As Standout Segment
LLY: Nasdaq 100 Drops 1% on Hot CPI, SOXX Falls 7th Day: Stock Market Today | 8 Of 11 Sectors Fall Wednesday As Defensives Lead | Watching Eli Lilly; Hearing Investor Business Daily SwingTrader Buys Stock
XOM: 8 Of 11 Sectors Fall Wednesday As Defensives Lead | Guyana May Scale Back LNG Plans As Exxon Needs More Gas For Its Wells, Sources Say | Cyclicals Lead Sectors In Tuesday Trading As Health Care Trails
COST: 8 Of 11 Sectors Fall Wednesday As Defensives Lead | 9 Of 11 Sectors Rise Friday As Real Estate Leads | RBC Capital Reiterates Sector Perform on Costco Wholesale, Maintains $1000 Price Target
CAT: Nasdaq 100 Drops 1% on Hot CPI, SOXX Falls 7th Day: Stock Market Today | What's Going On With Caterpillar Stock Wednesday? | Chip Stocks Slide as South Korea's KOSPI Plunges, J&J Sinks 6%: Stock Market Today

## Scores
```json
{
  "TSLA": -0.1,
  "AMD": 0.1,
  "PLTR": 0.3,
  "COIN": 0.4,
  "MSFT": -0.3,
  "JPM": 0.3,
  "LLY": 0.2,
  "XOM": -0.1,
  "COST": 0.3,
  "CAT": -0.1
}
```
