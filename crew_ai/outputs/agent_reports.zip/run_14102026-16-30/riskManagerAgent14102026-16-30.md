# Risk Manager Agent

## Proposed orders
1. SELL 22 MSFT @ limit 534.49 (RAMS 26.2) - RAMS 26.2 below sell level
2. SELL 72 PLTR @ limit 202.59 (RAMS 39.8) - RAMS 39.8 below sell level
3. SELL 6 COST @ limit 973.57 (RAMS 77.8) - take half profit
4. SELL 17 XOM @ limit 176.30 (RAMS 82.0) - take half profit

## Review
- **Order 1 – SELL 22 MSFT @ 534.49** – **APPROVED** – Reduces a tech position that is currently at a loss, has negative news sentiment (‑0.3) and the portfolio is in a bear regime; no sector‑concentration or overbought concerns.  
- **Order 2 – SELL 72 PLTR @ 202.59** – **APPROVED** – Closes the full PLTR position, limiting exposure to a tech stock that is under‑performing (‑1.4% unrealized) despite modest positive news; helps diversify the portfolio in a bear market.  
- **Order 3 – SELL 6 COST @ 973.57** – **APPROVED** – Takes partial profit on a consumer‑staples holding with positive news (+0.3) and modest upside; the sector is not over‑weighted and the trade does not increase risk.  
- **Order 4 – SELL 17 XOM @ 176.30** – **APPROVED** – Reduces energy exposure by half while locking in a small profit; the stock has slightly negative news (‑0.1) and the sell aligns with the overall defensive stance of the bear regime.