# Execution Log

- [1/1] SELL 40 PLTR @ limit 195.24 (RAMS 37.5, stop-loss 189.74) - RAMS 37.5 below sell level - OrderStatus.PENDING_NEW
