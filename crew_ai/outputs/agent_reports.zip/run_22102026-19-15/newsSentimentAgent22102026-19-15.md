# News Sentiment Agent

## Headlines
TSLA: Gov. Ron DeSantis Says Florida Will Legalize Tesla's Flying Roadster So It Can 'Leapfrog Golf Carts' — But His Term Is Almost Over | CLSA Upgrades Tesla to Hold, Raises Price Target to $400 | 'He Thrives on Chaos' — Elon Musk's First Wife Says He Can 'Jump Off the Edge of a Cliff and Invent a Parachute on the Way Down'
AMD: 10 Information Technology Stocks With Whale Alerts In Today’s Session | Meta Tumbles 6% on AI Spending Fears, 10-Year Yield Falls Below 5%: Stock Market Today | AMD Stock Drops 7% in Chip Sell-Off - Here's Why
PLTR: Citigroup Maintains Buy on Palantir Technologies, Raises Price Target to $250 | Stagwell Expands Strategic AI Partnership with Palantir | Palantir Names Aplos Data to Vanguard: Elite Partner Tier
COIN: Ripple Sees a $100 Million Opportunity for Banks—What’s in It for XRP? | 'Long Coins, Short Stocks': Expert Bullish on Bitcoin, Cautious on XRP, Coinbase, Circle | Coinbase Global Unit Reaches EUR3.3 Million Settlement with Irish Central Bank
MSFT: Is A War Imminent? Concerns Overshadow Strong Meta, Tesla Earnings | Uber Brings ChatGPT Work To All Employees With OpenAI | Microsoft and Boehringer Ingelheim Announce Strategic AI Collaboration
JPM: J.P. Morgan Asset Management Launches Tokenized Money Market Funds on Solana | $100 Invested In JPMorgan Chase 15 Years Ago Would Be Worth This Much Today | JPMorgan Chase Upgrades CME Group Inc. to Buy
LLY: Eli Lilly and Company Breaks Ground on $5B Integrated Manufacturing Site in Virginia | Defensives Lead Sectors In Thursday Trading As Growth Trails | Eli Lilly Starts Construction On $5B Production Site In Richmond, Virginia
XOM: 'Qatar Scours for More LNG to Boost Supply Outside Middle East' - Bloomberg Exclusive | Shell and ExxonMobil Joint Venture Infineum Explores $8 Billion Sale | Defensives Lead Sectors In Thursday Trading As Growth Trails
COST: IQBAR Launches Indulgent Protein Bites at Costco | Costco to Invest 4.475 Billion TWD in New Tainan Store | Costain Group PLC Appoints Joh. Berenberg, Gossler & Co. KG as Joint Corporate Broker
CAT: 10 Industrials Stocks With Whale Alerts In Today’s Session | Meta Tumbles 6% on AI Spending Fears, 10-Year Yield Falls Below 5%: Stock Market Today | Defensives Lead Sectors In Thursday Trading As Growth Trails

## Scores
```json
{
  "TSLA": 0.6,
  "AMD": -0.5,
  "PLTR": 0.7,
  "COIN": -0.2,
  "MSFT": 0.2,
  "JPM": 0.5,
  "LLY": 0.6,
  "XOM": 0.2,
  "COST": 0.5,
  "CAT": 0.0
}
```
