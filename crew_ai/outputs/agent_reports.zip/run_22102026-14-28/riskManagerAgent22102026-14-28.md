# Risk Manager Agent

## Proposed orders
1. SELL 67 XOM @ limit 175.99 (RAMS 33.0) - RAMS 33.0 below sell level
2. BUY 7 LLY @ limit 1308.94 (RAMS 80.9) - RAMS 80.9 strong and position in profit

## Review
- **Order 1 – SELL 67 XOM @ limit 175.99** – **APPROVED** – Reduces exposure to the energy sector (currently ~12% of portfolio) and cuts a losing position in a bear‑market regime; news on XOM is slightly negative, so selling aligns with risk limits.  

- **Order 2 – BUY 7 LLY @ limit 1308.94** – **REJECTED** – Would increase the healthcare concentration from ~1% to ~10% of the portfolio, breaching sector‑concentration limits, and adding new long exposure in a bear market despite positive news.