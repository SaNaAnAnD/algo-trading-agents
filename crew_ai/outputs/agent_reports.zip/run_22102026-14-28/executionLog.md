# Execution Log

- [1/1] SELL 67 XOM @ limit 175.99 (RAMS 33.0, stop-loss 173.25) - RAMS 33.0 below sell level - OrderStatus.PENDING_NEW
