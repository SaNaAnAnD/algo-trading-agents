# News Sentiment Agent

## Headlines
TSLA: Nasdaq Down 400 Points; Tesla Shares Fall After Q3 Results | JP Morgan Maintains Neutral on Tesla, Raises Price Target to $430 | Tesla Just Reversed Its 2026 CapEx Surge — Why Gordon Johnson Asks If It's the 'End of the AI Trade'
AMD: Ken Griffin Calls AI a Bubble After Citadel Bought the Dip | Why Is Advanced Micro Devices Stock Trending Wednesday? | Susquehanna Adjusts Price Target on Advanced Micro Devices to $620 From $550
PLTR: Stagwell Expands Partnership With Palantir Over AI-Powered Marketing Services | Citi Maintains Buy Rating and Raises Price Target for Palantir | Cathie Wood Adds Netflix After Earnings Selloff, Ark Keeps Selling Palantir Stock
COIN: 'Long Coins, Short Stocks': Expert Bullish on Bitcoin, Cautious on XRP, Coinbase, Circle | Coinbase Global Unit Reaches EUR3.3 Million Settlement with Irish Central Bank | Central Bank Of Ireland Fined Coinbase Ireland €3.25M For Breaching Safeguarding And Outsourcing Obligations Under Electronic Money Regulations 2011
MSFT: Jensen Huang on Keeping AI Under Control: 'You Contain the Baby and You Monitor It' | Infragistics Announces Collaboration with Microsoft to Advance Blazor | Ted Lieu Pushes Congress to Act as NSA Warns of Critical Cyber Vulnerabilities: ‘We Need More Cybersecurity Personnel’
JPM: 'Unvetted AI Agents Are Accessing U.S. Bank Accounts' - Axios | JPMorgan Chase Bank, N.A. Acts as Administrative Agent for Watsco Credit Facility | JPMorgan Chase & Co. Reports Change in Major Holding in Crest Nicholson Holdings PLC
LLY: If You Invested $100 In Eli Lilly Stock 20 Years Ago, You Would Have This Much Today | Mubadala Bio and Lilly Announce Landmark Agreement to Advance Pharmaceutical Contract Manufacturing in Abu Dhabi | Leerink Partners Maintains Outperform on Eli Lilly, Raises Price Target to $1316
XOM: 'Shell And Exxon’s $8B UK Chemicals Unit Put Up For Sale' - Financial Times | 'Kashagan Arbitration Court Invalidates $12 Billion of Cost Claim' - Bloomberg | Jury Verdict in Mazza v. ExxonMobil Litigation
COST: Costco to Invest 4.475 Billion TWD in New Tainan Store | Costain Group PLC Appoints Joh. Berenberg, Gossler & Co. KG as Joint Corporate Broker | Cyclicals Top Sectors In Wednesday Trading As Defensives Trail
CAT: IronSight AI and Fast Iron Partner to Enhance Inventory Management for Caterpillar Dealers | 10 Industrials Stocks Whale Activity In Today’s Session | Cyclicals Top Sectors In Wednesday Trading As Defensives Trail

## Scores
```json
{
  "TSLA": -0.4,
  "AMD": 0.2,
  "PLTR": 0.3,
  "COIN": -0.5,
  "MSFT": 0.1,
  "JPM": -0.2,
  "LLY": 0.7,
  "XOM": -0.1,
  "COST": 0.2,
  "CAT": 0.4
}
```
